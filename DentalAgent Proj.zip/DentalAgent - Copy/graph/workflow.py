# graph/workflow.py
# LangGraph stateful workflow for DentalAgent AI

from langgraph.graph import StateGraph, END
from graph.state import AgentState
from graph.nodes import (
    initialize_state_node,
    authentication_node,
    intent_node,
    appointment_validation_node,
    availability_check_node,
    risk_detection_node,
    confirmation_node,
    draft_generation_node,
    human_in_the_loop_node,
    human_decision_node,
    finalization_node,
    error_handler_node,
)

# ── Routing functions ──────────────────────────────────────────────────────────

def route_after_auth(state: AgentState) -> str:
    if not state.get("authenticated"):
        return "error"
    return "intent"

def route_after_intent(state: AgentState) -> str:
    if state.get("terminal_status") in ("FAILED", "NEED_INFO"):
        return "error"
    return "risk_detection"

def route_after_risk(state: AgentState) -> str:
    if state.get("risk_detected"):
        return "draft"   # ESCALATE path goes straight to draft (skips confirmation)
    return "appt_validation"

def route_after_appt_validation(state: AgentState) -> str:
    if state.get("terminal_status") in ("FAILED", "NEED_INFO"):
        return "error"
    intent = state.get("intent", "")
    if intent == "reschedule":
        return "availability"
    if intent == "prep_instructions":
        return "draft"
    return "confirmation"   # cancel goes to confirmation

def route_after_availability(state: AgentState) -> str:
    if state.get("terminal_status") in ("FAILED", "NEED_INFO"):
        return "error"
    return "confirmation"

def route_after_confirmation(state: AgentState) -> str:
    if state.get("terminal_status") in ("FAILED",):
        return "error"
    return "draft"

def route_after_hitl(state: AgentState) -> str:
    # After HITL pause the graph ends; external caller resolves and calls human_decision
    return END

def route_after_draft(state: AgentState) -> str:
    if state.get("terminal_status") == "FAILED":
        return "error"
    return "hitl"

# ── Build graph ────────────────────────────────────────────────────────────────

def build_graph() -> StateGraph:
    g = StateGraph(AgentState)

    g.add_node("init",            initialize_state_node)
    g.add_node("auth",            authentication_node)
    g.add_node("intent",          intent_node)
    g.add_node("risk_detection",  risk_detection_node)
    g.add_node("appt_validation", appointment_validation_node)
    g.add_node("availability",    availability_check_node)
    g.add_node("confirmation",    confirmation_node)
    g.add_node("draft",           draft_generation_node)
    g.add_node("hitl",            human_in_the_loop_node)
    g.add_node("human_decision",  human_decision_node)
    g.add_node("finalize",        finalization_node)
    g.add_node("error",           error_handler_node)

    g.set_entry_point("init")
    g.add_edge("init", "auth")

    g.add_conditional_edges("auth",            route_after_auth,            {"intent": "intent",                 "error": "error"})
    g.add_conditional_edges("intent",          route_after_intent,          {"risk_detection": "risk_detection", "error": "error"})
    g.add_conditional_edges("risk_detection",  route_after_risk,            {"appt_validation": "appt_validation", "draft": "draft"})
    g.add_conditional_edges("appt_validation", route_after_appt_validation, {"confirmation": "confirmation", "availability": "availability", "draft": "draft", "error": "error"})
    g.add_conditional_edges("availability",    route_after_availability,    {"confirmation": "confirmation",     "error": "error"})
    g.add_conditional_edges("confirmation",    route_after_confirmation,    {"draft": "draft",                  "error": "error"})
    g.add_conditional_edges("draft",           route_after_draft,           {"hitl": "hitl",                    "error": "error"})
    g.add_edge("hitl",           "human_decision")
    g.add_edge("human_decision", "finalize")
    g.add_edge("finalize",       END)
    g.add_edge("error",          END)

    return g.compile()


# ── Public helper ─────────────────────────────────────────────────────────────

def _normalize_initial_state(initial_state: dict) -> dict:
    """Normalize caller input keys to graph state keys."""
    state = dict(initial_state or {})

    # UI/CLI aliases
    if "requested_date" in state and "new_date" not in state:
        state["new_date"] = state.get("requested_date")
    if "raw_input" in state and "symptoms" not in state:
        state["symptoms"] = state.get("raw_input")
    if "human_decision" in state and "human_action" not in state:
        state["human_action"] = state.get("human_decision")
    if "human_edited_response" in state and "edited_response" not in state:
        state["edited_response"] = state.get("human_edited_response")

    # Keep both names for downstream UI compatibility
    if "human_action" in state and "human_decision" not in state:
        state["human_decision"] = state["human_action"]
    if "new_date" in state and "requested_date" not in state:
        state["requested_date"] = state["new_date"]

    return state


def run_workflow(initial_state: dict | None = None, **kwargs) -> dict:
    """Run the full graph and return final state."""
    merged = dict(initial_state or {})
    merged.update(kwargs)
    graph = build_graph()
    result = graph.invoke(_normalize_initial_state(merged))
    return result
