# graph/nodes.py
# All LangGraph node functions for DentalAgent AI

import uuid
import os
from datetime import datetime

from data.store import (
    authenticate_patient, get_appointment, cancel_appointment,
    reschedule_appointment, is_slot_available, get_prep_instructions,
    ESCALATION_TEMPLATE,
)
from graph.state import AgentState
from middleware.config import ModelRetryMiddleware
from utils.logging import get_logger

logger = get_logger("Nodes")

# ── LLM setup ─────────────────────────────────────────────────────────────────
def _get_llm():
    from langchain_openai import ChatOpenAI
    return ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0.1,
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
    )

def _llm_invoke(prompt: str) -> str:
    """Call LLM with ModelRetryMiddleware (retry once)."""
    llm = _get_llm()
    def call(p, **kw):
        from langchain_core.messages import HumanMessage
        return llm.invoke([HumanMessage(content=p)]).content
    retry = ModelRetryMiddleware(call, max_retries=1)
    return retry.invoke(prompt)

def _trace(state: AgentState, node_name: str) -> AgentState:
    route = list(state.get("route_taken", []))
    route.append(node_name)
    state["route_taken"] = route
    steps = list(state.get("execution_trace", []))
    steps.append({
        "time": datetime.now().strftime("%H:%M:%S"),
        "node": node_name,
        "detail": state.get("terminal_status", "RUNNING") or "RUNNING",
    })
    state["execution_trace"] = steps
    logger.info(f"NODE: {node_name}")
    return state

# ── ESCALATION KEYWORDS (rule-based, no LLM judgment) ─────────────────────────
ESCALATION_KEYWORDS = [
    "uncontrolled bleeding", "bleeding won't stop", "can't stop bleeding",
    "severe swelling", "swelling affecting breathing", "can't breathe",
    "difficulty breathing", "allergic reaction", "anaphylaxis",
    "lost consciousness", "passed out", "unconscious",
    "severe infection", "high fever", "jaw trauma", "jaw broken",
    "broken jaw", "facial trauma",
]

def detect_risk(text: str) -> tuple[bool, str]:
    """Rule-based risk detection. Returns (risk_detected, reason)."""
    lower = text.lower()
    for kw in ESCALATION_KEYWORDS:
        if kw in lower:
            return True, f"Escalation keyword detected: '{kw}'"
    return False, ""


def infer_intent_from_text(text: str) -> str:
    """
    Lightweight rule-based intent inference from free text.
    Returns one of: cancel | reschedule | prep_instructions | unknown
    """
    if not text:
        return "unknown"
    t = text.lower().strip()

    cancel_terms = [
        "cancel appointment",
        "cancel my appointment",
        "cancel",
        "i want to cancel",
    ]
    reschedule_terms = [
        "reschedule appointment",
        "reschedule",
        "change appointment",
        "move appointment",
        "as soon as possible",
        "earliest",
        "see doctor as soon as possible",
        "i want to see doctor",
    ]
    prep_terms = [
        "prep",
        "preparation",
        "prepare",
        "instructions",
        "before appointment",
    ]

    if any(x in t for x in cancel_terms):
        return "cancel"
    if any(x in t for x in reschedule_terms):
        return "reschedule"
    if any(x in t for x in prep_terms):
        return "prep_instructions"
    return "unknown"

# ══════════════════════════════════════════════════════════════════════════════
# NODE FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def initialize_state_node(state: AgentState) -> AgentState:
    state["run_id"] = str(uuid.uuid4())[:8].upper()
    state["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    state.setdefault("route_taken", [])
    state.setdefault("execution_trace", [])
    state.setdefault("risk_detected", False)
    state.setdefault("confirmed", False)
    state.setdefault("terminal_status", "")
    state.setdefault("draft_response", "")
    state.setdefault("final_response", "")
    state.setdefault("human_action", state.get("human_decision", ""))
    state.setdefault("human_decision", state.get("human_action", ""))
    state.setdefault("escalation_message", "")
    state.setdefault("error_message", None)
    return _trace(state, "InitializeStateNode")


def authentication_node(state: AgentState) -> AgentState:
    state = _trace(state, "AuthenticationNode")
    pid = state.get("patient_id", "").strip()
    if authenticate_patient(pid):
        state["authenticated"] = True
    else:
        state["authenticated"] = False
        state["terminal_status"] = "FAILED"
        state["error_message"] = f"Patient ID '{pid}' not found. Please check and try again."
    return state


def intent_node(state: AgentState) -> AgentState:
    state = _trace(state, "IntentNode")
    intent = state.get("intent", "").strip().lower()
    valid = {"cancel", "reschedule", "prep_instructions"}
    if intent not in valid:
        free_text = " ".join(
            filter(
                None,
                [
                    state.get("raw_input", ""),
                    state.get("symptoms", ""),
                ],
            )
        )
        inferred = infer_intent_from_text(free_text)
        if inferred in valid:
            state["intent"] = inferred
            return state
    if intent not in valid:
        state["terminal_status"] = "NEED_INFO"
        state["error_message"] = f"Intent '{intent}' not recognized. Choose: cancel, reschedule, or prep_instructions."
    return state


def appointment_validation_node(state: AgentState) -> AgentState:
    state = _trace(state, "AppointmentValidationNode")
    appt = get_appointment(state.get("appointment_id", ""), state.get("patient_id", ""))
    if appt:
        state["appointment"] = appt
    else:
        state["appointment"] = None
        state["terminal_status"] = "NEED_INFO"
        state["error_message"] = "Appointment not found or does not belong to this patient."
    return state


def availability_check_node(state: AgentState) -> AgentState:
    state = _trace(state, "AvailabilityCheckNode")
    new_date = (state.get("new_date") or state.get("requested_date") or "").strip()
    state["new_date"] = new_date
    state["requested_date"] = new_date
    if not new_date:
        state["terminal_status"] = "NEED_INFO"
        state["error_message"] = "No new date provided for rescheduling."
        return state
    if is_slot_available(new_date):
        pass  # OK, continue
    else:
        state["terminal_status"] = "NEED_INFO"
        state["error_message"] = (
            f"The slot '{new_date}' is not available. "
            "Please choose from available slots or contact the clinic."
        )
    return state


def risk_detection_node(state: AgentState) -> AgentState:
    state = _trace(state, "RiskDetectionNode")
    # Check symptoms field AND all text in state
    text_to_check = " ".join(filter(None, [
        state.get("symptoms", "") or state.get("raw_input", ""),
        state.get("intent", ""),
    ]))
    risk, reason = detect_risk(text_to_check)
    state["risk_detected"] = risk
    state["risk_reason"] = reason if risk else None
    if risk:
        state["terminal_status"] = "ESCALATE"
        logger.warning(f"RISK DETECTED: {reason}")
    return state


def confirmation_node(state: AgentState) -> AgentState:
    """
    This node is used BEFORE executing destructive actions (cancel/reschedule).
    The actual YES/NO input is collected by CLI or Streamlit BEFORE calling this node.
    confirmed flag must already be set in state.
    """
    state = _trace(state, "ConfirmationNode")
    if not state.get("confirmed", False):
        state["terminal_status"] = "FAILED"
        state["error_message"] = "Action cancelled by user at confirmation step."
    return state


def draft_generation_node(state: AgentState) -> AgentState:
    state = _trace(state, "DraftGenerationNode")
    intent = state.get("intent", "")
    appt = state.get("appointment") or {}

    # ── ESCALATION path ────────────────────────────────────────────────────────
    if state.get("terminal_status") == "ESCALATE":
        risk_reason = state.get("risk_reason", "")
        try:
            personalized = _llm_invoke(
                f"You are a dental clinic assistant. A patient described: '{state.get('symptoms', '')}'. "
                f"This is a medical emergency ({risk_reason}). "
                "Write a short, calm, urgent message directing them to call 911 or go to the ER immediately. "
                "Do NOT give any clinical advice. Keep it under 60 words. "
                "Start with the word URGENT."
            )
        except Exception:
            personalized = ESCALATION_TEMPLATE
        state["draft_response"] = personalized
        state["escalation_message"] = personalized
        return state

    # ── Cancel ────────────────────────────────────────────────────────────────
    if intent == "cancel":
        ok = cancel_appointment(state.get("appointment_id", ""), state.get("patient_id", ""))
        if ok:
            base = (
                f"Your appointment (ID: {appt.get('appointment_id','')}) "
                f"for {appt.get('type','')} on {appt.get('date','')} "
                "has been successfully cancelled. "
                "We hope to see you again soon. Please contact us if you need to rebook."
            )
        else:
            base = "We were unable to cancel the appointment. Please contact the clinic directly."
        try:
            draft = _llm_invoke(
                f"You are a friendly dental clinic assistant. Rewrite this cancellation message "
                f"in a warm, professional tone (max 80 words): {base}"
            )
        except Exception:
            draft = base
        state["draft_response"] = draft
        state["terminal_status"] = "READY"

    # ── Reschedule ────────────────────────────────────────────────────────────
    elif intent == "reschedule":
        new_date = state.get("new_date", "")
        ok = reschedule_appointment(state.get("appointment_id", ""), state.get("patient_id", ""), new_date)
        if ok:
            base = (
                f"Your appointment (ID: {appt.get('appointment_id','')}) "
                f"has been rescheduled to {new_date}. "
                "Please arrive 10 minutes early. We look forward to seeing you!"
            )
        else:
            base = "We were unable to reschedule the appointment. Please contact the clinic directly."
        try:
            draft = _llm_invoke(
                f"You are a friendly dental clinic assistant. Rewrite this rescheduling confirmation "
                f"in a warm, professional tone (max 80 words): {base}"
            )
        except Exception:
            draft = base
        state["draft_response"] = draft
        state["terminal_status"] = "READY"

    # ── Prep Instructions ─────────────────────────────────────────────────────
    elif intent == "prep_instructions":
        appt_type = appt.get("type", "Default")
        raw_prep = get_prep_instructions(appt_type)
        base = (
            f"Preparation instructions for your {appt_type} appointment "
            f"on {appt.get('date','')}: {raw_prep}"
        )
        try:
            draft = _llm_invoke(
                f"You are a friendly dental clinic assistant. Rewrite these preparation instructions "
                f"in a clear, warm, patient-friendly tone (max 100 words). "
                f"Do NOT give clinical advice. Use simple language: {base}"
            )
        except Exception:
            draft = base
        state["draft_response"] = draft
        state["terminal_status"] = "READY"

    else:
        state["draft_response"] = "Unable to generate a response. Please contact the clinic."
        state["terminal_status"] = "FAILED"

    return state


def human_in_the_loop_node(state: AgentState) -> AgentState:
    """
    Pause point. Sets human_action = PENDING.
    Resolution happens OUTSIDE the graph (in CLI or Streamlit).
    """
    state = _trace(state, "HumanInTheLoopMiddleware")
    action = (state.get("human_action") or state.get("human_decision") or "").strip().lower()
    if action not in ("approve", "edit", "rewrite"):
        state["human_action"] = "PENDING"
        state["human_decision"] = "pending"
    else:
        state["human_action"] = action
        state["human_decision"] = action
    return state


def human_decision_node(state: AgentState) -> AgentState:
    """
    Applied AFTER human review resolves the PENDING state.
    human_action should already be set to approve / edit / rewrite by caller.
    """
    state = _trace(state, "HumanDecisionNode")
    action = (state.get("human_action") or state.get("human_decision") or "approve").strip().lower()
    state["human_action"] = action
    state["human_decision"] = action
    if action in ("pending", "pended"):
        state["terminal_status"] = "PENDING"
        state["final_response"] = ""
        return state
    if action == "rewrite":
        # Re-run draft generation
        state = draft_generation_node(state)
        state["human_action"] = "approve"
        state["human_decision"] = "approve"
        state["final_response"] = state["draft_response"]
    elif action == "edit":
        state["final_response"] = state.get("edited_response") or state.get("human_edited_response") or state.get("draft_response", "")
    else:
        state["final_response"] = state.get("draft_response", "")
    return state


def finalization_node(state: AgentState) -> AgentState:
    state = _trace(state, "FinalizationNode")
    if state.get("terminal_status") == "PENDING":
        return state
    if not state.get("terminal_status"):
        state["terminal_status"] = "READY"
    if not state.get("final_response"):
        state["final_response"] = state.get("draft_response", "No response generated.")
    return state


def error_handler_node(state: AgentState) -> AgentState:
    state = _trace(state, "ErrorHandlerNode")
    if not state.get("terminal_status"):
        state["terminal_status"] = "FAILED"
    err = state.get("error_message", "An unexpected error occurred.")
    state["final_response"] = f"We could not complete your request. {err} Please contact the clinic for assistance."
    return state
