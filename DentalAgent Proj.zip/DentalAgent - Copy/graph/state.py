# graph/state.py
# Shared LangGraph state schema for DentalAgent AI

from typing import TypedDict, Optional, List

class AgentState(TypedDict, total=False):
    # ── Run metadata ───────────────────────────────────────────────────────────
    run_id: str
    timestamp: str

    # ── Authentication ─────────────────────────────────────────────────────────
    patient_id: str
    authenticated: bool

    # ── Intent ────────────────────────────────────────────────────────────────
    intent: str           # "cancel" | "reschedule" | "prep_instructions"

    # ── Appointment ────────────────────────────────────────────────────────────
    appointment_id: str
    appointment: Optional[dict]
    new_date: Optional[str]
    requested_date: Optional[str]

    # ── Risk / Safety ─────────────────────────────────────────────────────────
    risk_detected: bool
    risk_reason: Optional[str]
    symptoms: Optional[str]
    raw_input: Optional[str]
    escalation_message: Optional[str]

    # ── Workflow control ──────────────────────────────────────────────────────
    confirmed: bool                   # user said YES to "are you sure?"
    terminal_status: str              # READY | NEED_INFO | ESCALATE | FAILED
    route_taken: List[str]            # node trace
    execution_trace: List[dict]

    # ── Drafts & responses ────────────────────────────────────────────────────
    draft_response: str
    final_response: str
    human_action: str                 # approve | edit | rewrite
    human_decision: str               # alias used by UI/CLI
    edited_response: Optional[str]
    human_edited_response: Optional[str]

    # ── Errors ────────────────────────────────────────────────────────────────
    error_message: Optional[str]
