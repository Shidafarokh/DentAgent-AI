# DentalAgent AI

Clinical appointment assistant with:
- LangGraph workflow orchestration
- Streamlit UI (Patient Panel + Reviewer Panel)
- CLI mode
- In-memory data store

This README is aligned with the current codebase and UI behavior.

## What The App Does

The system supports three patient intents:
- `cancel`
- `reschedule`
- `prep_instructions`

Core behavior:
- Validates patient and appointment ownership
- Detects emergency-risk text and escalates
- Uses HITL (human-in-the-loop) for reviewer approval
- Produces final responses after reviewer action (`approve`, `edit`, `rewrite`)

## Current Project Structure

```text
DentalAgent/
├── app.py
├── cli.py
├── requirements.txt
├── .env.example
├── data/
│   └── store.py
├── graph/
│   ├── state.py
│   ├── nodes.py
│   └── workflow.py
├── middleware/
│   └── config.py
└── utils/
    ├── logging.py
    └── masking.py
```

## Setup (Windows)

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Set `OPENAI_API_KEY` in `.env`.

## Run

CLI:
```powershell
python cli.py
```

Streamlit UI:
```powershell
streamlit run app.py
```

## UI Overview

### Patient Panel
- Patient login (`Patient ID` + `Password`)
- Forgot password flow (temporary password generation)
- Upcoming appointments display
- Request form:
  - Request Type
  - Appointment ID
  - Additional Notes
- Reschedule flow:
  - Shows only doctor-specific candidate options for that appointment
  - Patient can choose one option or cancel
- Emergency guard:
  - If emergency phrases are detected in notes, app stops normal flow and shows 911 escalation

### Reviewer Panel
- Doctor availability management (week constrained to 2026-03-09 to 2026-03-15)
- Availability board (occupied/free visualization)
- Weekly appointment occupancy calendar
- Appointment detail + reminder editor
- Draft Response editor
- Reviewer decision controls
- Execution trace + optional Debug Mode JSON view

## Data Model (Current)

Defined in `data/store.py`:
- `appointments`: currently 26 fake records
- `known_patients`: currently 21 patient IDs (`P001` ... `P021`)
- `patient_passwords`: default password is `123` for all listed patients
- `known_patient_names`
- `doctor_roster`
- `available_slots`
- `prep_instructions`
- `ESCALATION_TEMPLATE`

## Workflow Architecture

Defined in `graph/workflow.py` and `graph/nodes.py`.

Main graph path:
1. `init`
2. `auth`
3. `intent`
4. `risk_detection`
5. `appt_validation`
6. (`availability` only for reschedule)
7. `confirmation`
8. `draft`
9. `hitl`
10. `human_decision`
11. `finalize`

Error path:
- Any failure route goes to `error` then end.

## Decision Tree (YES / NO)

```text
Start
  |
  +-- Patient Auth valid?
  |     +-- NO  -> FAILED (stop)
  |     +-- YES
  |
  +-- Intent valid?
  |     +-- NO  -> NEED_INFO (stop)
  |     +-- YES
  |
  +-- Emergency risk detected?
  |     +-- YES -> ESCALATE -> Draft -> HITL -> Reviewer Approve/Edit/Rewrite -> Finalize
  |     +-- NO
  |
  +-- Appointment belongs to patient?
  |     +-- NO  -> NEED_INFO (stop)
  |     +-- YES
  |
  +-- Intent = Reschedule?
  |     +-- NO
  |     |    +-- Patient Confirm?
  |     |         +-- NO  -> FAILED (stop)
  |     |         +-- YES -> Draft -> HITL -> Reviewer decision -> Finalize
  |     |
  |     +-- YES
  |          +-- Slot available?
  |               +-- NO  -> NEED_INFO (stop)
  |               +-- YES
  |                    +-- Patient Confirm?
  |                         +-- NO  -> FAILED (stop)
  |                         +-- YES
  |                              +-- Reviewer Accept?
  |                                   +-- NO  -> NEED_INFO (reject_reschedule)
  |                                   +-- YES -> Final READY
```

### Mermaid Chart

```mermaid
flowchart TD
    A([Start]) --> B{Patient Auth valid?}
    B -- No --> B1([FAILED / Stop])
    B -- Yes --> C{Intent valid?}

    C -- No --> C1([NEED_INFO / Stop])
    C -- Yes --> D{Emergency risk detected?}

    D -- Yes --> D1([ESCALATE]) --> D2[Draft Generation] --> D3[HITL] --> D4{Reviewer Decision}
    D4 -- Approve --> D5([Finalize READY])
    D4 -- Edit --> D5
    D4 -- Rewrite --> D5

    D -- No --> E{Appointment belongs to patient?}
    E -- No --> E1([NEED_INFO / Stop])
    E -- Yes --> F{Intent = Reschedule?}

    F -- No --> G{Patient Confirm?}
    G -- No --> G1([FAILED / Stop])
    G -- Yes --> G2[Draft Generation] --> G3[HITL] --> G4{Reviewer Decision}
    G4 -- Approve/Edit/Rewrite --> G5([Finalize READY])

    F -- Yes --> H{Slot available?}
    H -- No --> H1([NEED_INFO / Stop])
    H -- Yes --> I{Patient Confirm?}
    I -- No --> I1([FAILED / Stop])
    I -- Yes --> J{Reviewer Accept?}
    J -- No --> J1([NEED_INFO / reject_reschedule])
    J -- Yes --> J2([Finalize READY])
```

## Terminal Status Values

- `READY`
- `NEED_INFO`
- `ESCALATE`
- `FAILED`
- `PENDING`

## Function Map

### `app.py`

Theme/session:
- `apply_theme(escalation: bool = False)`
- `init_session()`
- `status_badge(status: str) -> str`
- `add_chat(role: str, message: str) -> None`

Safety + slots:
- `detect_emergency_text(text: str) -> bool`
- `_parse_slot(slot: str) -> tuple[str, str, str]`
- `get_week_slots(...) -> list[str]`
- `_occupied_doctor_keys() -> set[tuple[str, str, str]]`
- `get_free_week_slots(...) -> list[str]`
- `get_availability_board_slots(...) -> list[str]`

Patient data rendering:
- `get_patient_appointments(patient_id: str) -> list[dict]`
- `render_patient_upcoming_appointments(patient_id: str) -> None`
- `render_slots_calendar(...) -> None`

Reviewer rendering:
- `render_reviewer_appointments_calendar() -> None`
- `render_reviewer_patient_table() -> None`

Main panel rendering:
- `render_left_panel() -> None`
- `render_right_panel() -> None`

Workflow integration:
- `_run_draft_workflow() -> None`
- `_finalize(decision: str, reschedule_approved: bool | None = None) -> None`
- `main() -> None`

### `data/store.py`

State/data operations:
- `get_appointment(appointment_id, patient_id)`
- `cancel_appointment(appointment_id, patient_id)`
- `_parse_slot(slot_str)`
- `reschedule_appointment(appointment_id, patient_id, new_date)`
- `is_slot_available(date_str)`
- `get_prep_instructions(appointment_type)`
- `authenticate_patient(patient_id)`
- `authenticate_patient_password(patient_id, password)`
- `reset_patient_password(patient_id)`

### `graph/workflow.py`

Routing:
- `route_after_auth(state)`
- `route_after_intent(state)`
- `route_after_risk(state)`
- `route_after_appt_validation(state)`
- `route_after_availability(state)`
- `route_after_confirmation(state)`
- `route_after_hitl(state)`
- `route_after_draft(state)`

Build/run:
- `build_graph()`
- `_normalize_initial_state(initial_state: dict) -> dict`
- `run_workflow(initial_state: dict | None = None, **kwargs) -> dict`

### `graph/nodes.py`

Helpers:
- `_get_llm()`
- `_llm_invoke(prompt: str) -> str`
- `_trace(state, node_name)`
- `detect_risk(text: str) -> tuple[bool, str]`

Nodes:
- `initialize_state_node(state)`
- `authentication_node(state)`
- `intent_node(state)`
- `appointment_validation_node(state)`
- `availability_check_node(state)`
- `risk_detection_node(state)`
- `confirmation_node(state)`
- `draft_generation_node(state)`
- `human_in_the_loop_node(state)`
- `human_decision_node(state)`
- `finalization_node(state)`
- `error_handler_node(state)`

### `middleware/config.py`

- `ModelRetryMiddleware.__init__(...)`
- `ModelRetryMiddleware.invoke(...)`
- `HumanInTheLoopMiddleware.pause(state)`
- `HumanInTheLoopMiddleware.resume(state, decision, edited_text="")`

### `utils/masking.py`

- `mask_patient_id(patient_id: str) -> str`
- `mask_appointment_id(appt_id: str) -> str`
- `mask_date(date_str: str) -> str`
- `mask_state_for_trace(state: dict) -> dict`

### `utils/logging.py`

- `get_logger(name: str = "DentalAgent")`
- `setup_logger(name: str = "DentalAgent")`
- `log_run_summary(state: dict) -> None`

## Notes

- The app is stateful through `st.session_state`.
- Streamlit UI and CLI both call `run_workflow(...)`.
- UI contains additional guardrails/UX logic beyond graph nodes (for example: immediate 911 emergency guard in patient form).
