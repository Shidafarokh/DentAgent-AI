# utils/masking.py
# Mask sensitive identifiers before logging or displaying in traces

import re

def mask_patient_id(patient_id: str) -> str:
    """P001 -> P***"""
    if not patient_id:
        return "****"
    return patient_id[0] + "***"

def mask_appointment_id(appt_id: str) -> str:
    """A123 -> A***"""
    if not appt_id:
        return "****"
    return appt_id[0] + "***"

def mask_date(date_str: str) -> str:
    """2026-03-02 09:00 -> 2026-**-** **:**"""
    if not date_str:
        return "****-**-** **:**"
    return re.sub(r"\d", "*", date_str, count=0)

def mask_state_for_trace(state: dict) -> dict:
    """Return a copy of state with sensitive fields masked."""
    safe = dict(state)
    if "patient_id" in safe:
        safe["patient_id"] = mask_patient_id(safe["patient_id"])
    if "appointment_id" in safe:
        safe["appointment_id"] = mask_appointment_id(safe["appointment_id"])
    if "appointment" in safe and safe["appointment"]:
        appt = dict(safe["appointment"])
        appt["patient_id"] = mask_patient_id(appt.get("patient_id", ""))
        appt["appointment_id"] = mask_appointment_id(appt.get("appointment_id", ""))
        safe["appointment"] = appt
    return safe
