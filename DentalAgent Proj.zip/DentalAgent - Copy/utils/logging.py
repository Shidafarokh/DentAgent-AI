# utils/logging.py
# Simple structured logger for DentalAgent AI

import logging
import sys

def get_logger(name: str = "DentalAgent") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            "[%(asctime)s] %(levelname)s %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        ))
        logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return logger


def setup_logger(name: str = "DentalAgent") -> logging.Logger:
    """Backward-compatible alias used by CLI."""
    return get_logger(name)


def log_run_summary(state: dict) -> None:
    """Lightweight run summary logger for CLI/UI."""
    logger = get_logger("DentalAgent.RunSummary")
    logger.info(
        "run_id=%s status=%s intent=%s patient_id=%s appointment_id=%s action=%s",
        state.get("run_id", "N/A"),
        state.get("terminal_status", "N/A"),
        state.get("intent", "N/A"),
        state.get("patient_id", "N/A"),
        state.get("appointment_id", "N/A"),
        state.get("human_action", state.get("human_decision", "N/A")),
    )
