#!/usr/bin/env python
# cli.py
# CLI entry point for DentalAgent AI
# Run: python cli.py

from __future__ import annotations
import os
import sys
from dotenv import load_dotenv

load_dotenv()

# ── Validate API key early ────────────────────────────────────────────────────
if not os.environ.get("OPENAI_API_KEY"):
    print("\n[ERROR] OPENAI_API_KEY is not set.")
    print("Please copy .env.example to .env and add your key.\n")
    sys.exit(1)

from data.store import available_slots
from graph.workflow import run_workflow
from utils.masking import mask_patient_id, mask_appointment_id, mask_date
from utils.logging import setup_logger, log_run_summary

logger = setup_logger("DentalAgent.CLI")

# ── ANSI Colors for Windows (works in Windows Terminal / PowerShell 7+) ───────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

INTENT_MAP = {
    "1": "cancel",
    "2": "reschedule",
    "3": "prep_instructions",
}


def banner() -> None:
    print(f"\n{BOLD}{CYAN}{'=' * 60}{RESET}")
    print(f"{BOLD}{CYAN}   DentalAgent AI — Appointment Assistant{RESET}")
    print(f"{BOLD}{CYAN}   Agentic AI Project 4 — Shida Farokhnejad{RESET}")
    print(f"{BOLD}{CYAN}{'=' * 60}{RESET}\n")


def section(title: str) -> None:
    print(f"\n{BOLD}{YELLOW}── {title} {'─' * (50 - len(title))}{RESET}")


def success(msg: str) -> None:
    print(f"{GREEN}✔  {msg}{RESET}")


def error(msg: str) -> None:
    print(f"{RED}✘  {msg}{RESET}")


def info(msg: str) -> None:
    print(f"{CYAN}ℹ  {msg}{RESET}")


def main() -> None:
    banner()

    # ── Step 1: Patient ID ────────────────────────────────────────────────────
    section("Step 1 — Patient Authentication")
    patient_id = input("  Enter your Patient ID (e.g. P001): ").strip().upper()
    if not patient_id:
        error("No Patient ID entered. Exiting.")
        sys.exit(1)

    # ── Step 2: Intent ────────────────────────────────────────────────────────
    section("Step 2 — Select Intent")
    print("  1. Cancel appointment")
    print("  2. Reschedule appointment")
    print("  3. Request preparation instructions")
    choice = input("  Enter choice (1/2/3): ").strip()
    intent = INTENT_MAP.get(choice, "unknown")
    if intent == "unknown":
        error("Invalid choice. Exiting.")
        sys.exit(1)
    success(f"Intent selected: {intent}")

    # ── Step 3: Appointment ID ────────────────────────────────────────────────
    section("Step 3 — Appointment ID")
    appointment_id = input("  Enter Appointment ID (e.g. A123): ").strip().upper()

    # ── Step 4: New Date (reschedule only) ────────────────────────────────────
    requested_date = ""
    if intent == "reschedule":
        section("Step 4 — New Date")
        suggested_slots = available_slots[:3]
        info("Suggested slots:")
        print(f"  1. {suggested_slots[0]}")
        print(f"  2. {suggested_slots[1]}")
        print(f"  3. {suggested_slots[2]}")
        print("  4. None of these, cancel appointment")
        slot_choice = input("  Enter choice (1/2/3/4): ").strip()
        if slot_choice in ("1", "2", "3"):
            requested_date = suggested_slots[int(slot_choice) - 1]
            success(f"Selected new date: {requested_date}")
        elif slot_choice == "4":
            intent = "cancel"
            requested_date = ""
            info("No suggested time selected. Request will proceed as appointment cancellation.")
        else:
            error("Invalid choice. Exiting.")
            sys.exit(1)

    # ── Step 5: Confirmation ──────────────────────────────────────────────────
    section("Step 5 — Confirmation")
    action_label = {
        "cancel": f"cancel appointment {appointment_id}",
        "reschedule": f"reschedule appointment {appointment_id} to {requested_date}",
        "prep_instructions": f"get prep instructions for appointment {appointment_id}",
    }[intent]
    print(f"  You are about to: {BOLD}{action_label}{RESET}")
    confirm_input = input("  Are you sure? (YES/NO): ").strip().upper()
    confirmed = confirm_input == "YES"
    if not confirmed:
        error("Action cancelled by user.")
        print(f"\n  {YELLOW}Terminal Status: FAILED{RESET}\n")
        sys.exit(0)
    success("Confirmed.")

    # ── Step 6: Run Workflow ──────────────────────────────────────────────────
    section("Step 6 — Running Workflow")
    info("Processing your request through DentalAgent workflow...")

    try:
        result = run_workflow(
            patient_id=patient_id,
            intent=intent,
            appointment_id=appointment_id,
            requested_date=requested_date,
            confirmed=confirmed,
            human_decision="pending",  # will be collected after draft
        )
    except Exception as e:
        error(f"Workflow error: {e}")
        sys.exit(1)

    # ── Show Draft ────────────────────────────────────────────────────────────
    section("Draft Response (Reviewer View)")
    if result.get("escalation_message"):
        print(f"\n{RED}{result['escalation_message']}{RESET}")
    else:
        print(f"\n{result.get('draft_response', '[No draft generated]')}")

    # ── Step 7: Human Decision ────────────────────────────────────────────────
    section("Step 7 — Reviewer Decision (Human-in-the-Loop)")
    print("  1. Approve")
    print("  2. Edit")
    print("  3. Rewrite")
    decision_choice = input("  Enter reviewer decision (1/2/3): ").strip()
    decision_map = {"1": "approve", "2": "edit", "3": "rewrite"}
    human_decision = decision_map.get(decision_choice, "approve")

    human_edited_response = ""
    if human_decision == "edit":
        print("  Enter edited response (press Enter twice when done):")
        lines = []
        while True:
            line = input()
            if line == "":
                break
            lines.append(line)
        human_edited_response = "\n".join(lines)

    # ── Run Again With Human Decision ────────────────────────────────────────
    info("Applying reviewer decision and finalizing...")
    try:
        final_result = run_workflow(
            patient_id=patient_id,
            intent=intent,
            appointment_id=appointment_id,
            requested_date=requested_date,
            confirmed=confirmed,
            human_decision=human_decision,
            human_edited_response=human_edited_response,
        )
    except Exception as e:
        error(f"Finalization error: {e}")
        sys.exit(1)

    # ── Final Output ──────────────────────────────────────────────────────────
    section("Final Response")
    if final_result.get("escalation_message"):
        print(f"\n{RED}{final_result['escalation_message']}{RESET}")
    else:
        print(f"\n{GREEN}{final_result.get('final_response', '[No response]')}{RESET}")

    section("Run Summary")
    status = final_result.get("terminal_status", "UNKNOWN")
    status_color = GREEN if status == "READY" else (RED if status in ("FAILED", "ESCALATE") else YELLOW)

    print(f"  Run ID         : {BOLD}{final_result.get('run_id', 'N/A')}{RESET}")
    print(f"  Timestamp      : {final_result.get('timestamp', 'N/A')}")
    print(f"  Terminal Status: {status_color}{BOLD}{status}{RESET}")
    print(f"  Patient ID     : {mask_patient_id(patient_id)}")
    print(f"  Appointment ID : {mask_appointment_id(appointment_id)}")
    print(f"  Human Action   : {human_decision}")
    print(f"  Route Taken    :")
    for step in final_result.get("route_taken", []):
        print(f"    → {step}")

    log_run_summary(final_result)
    print(f"\n{BOLD}{CYAN}{'=' * 60}{RESET}")
    print(f"{BOLD}{GREEN}  DentalAgent AI — Session Complete{RESET}")
    print(f"{BOLD}{CYAN}{'=' * 60}{RESET}\n")


if __name__ == "__main__":
    main()
