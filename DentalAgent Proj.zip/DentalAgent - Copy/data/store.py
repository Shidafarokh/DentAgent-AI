# data/store.py
# In-memory structured data store for DentalAgent AI

appointments = [
    {"appointment_id": "A201", "patient_id": "P001", "patient_name": "Ali",  "type": "Cleaning",   "date": "2026-03-09 09:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A202", "patient_id": "P002", "patient_name": "Sara", "type": "Root Canal", "date": "2026-03-09 10:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "RESCHEDULED"},
    {"appointment_id": "A203", "patient_id": "P003", "patient_name": "Mina", "type": "Filling",    "date": "2026-03-09 11:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A204", "patient_id": "P004", "patient_name": "Reza", "type": "X-Ray",      "date": "2026-03-09 13:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CANCELLED"},
    {"appointment_id": "A205", "patient_id": "P005", "patient_name": "Nilo", "type": "Cleaning",   "date": "2026-03-09 14:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A206", "patient_id": "P001", "patient_name": "Ali",  "type": "Filling",    "date": "2026-03-09 15:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "RESCHEDULED"},
    {"appointment_id": "A207", "patient_id": "P002", "patient_name": "Sara", "type": "X-Ray",      "date": "2026-03-10 09:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A208", "patient_id": "P003", "patient_name": "Mina", "type": "Root Canal", "date": "2026-03-10 10:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A209", "patient_id": "P004", "patient_name": "Reza", "type": "Cleaning",   "date": "2026-03-10 11:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "CANCELLED"},
    {"appointment_id": "A210", "patient_id": "P005", "patient_name": "Nilo", "type": "Filling",    "date": "2026-03-10 13:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A211", "patient_id": "P006", "patient_name": "Liam", "type": "Cleaning",   "date": "2026-03-11 09:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "RESCHEDULED"},
    {"appointment_id": "A212", "patient_id": "P007", "patient_name": "Noah", "type": "Filling",    "date": "2026-03-11 10:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A213", "patient_id": "P008", "patient_name": "Emma", "type": "X-Ray",      "date": "2026-03-11 11:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A214", "patient_id": "P009", "patient_name": "Mila", "type": "Root Canal", "date": "2026-03-11 14:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A215", "patient_id": "P010", "patient_name": "Ethan","type": "Cleaning",   "date": "2026-03-12 09:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "CANCELLED"},
    {"appointment_id": "A216", "patient_id": "P011", "patient_name": "Ava",  "type": "Filling",    "date": "2026-03-12 13:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A217", "patient_id": "P012", "patient_name": "Leo",  "type": "X-Ray",      "date": "2026-03-13 10:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "RESCHEDULED"},
    {"appointment_id": "A218", "patient_id": "P013", "patient_name": "Nora", "type": "Cleaning",   "date": "2026-03-13 14:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A219", "patient_id": "P014", "patient_name": "Owen", "type": "Root Canal", "date": "2026-03-14 11:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A220", "patient_id": "P015", "patient_name": "Ivy",  "type": "Filling",    "date": "2026-03-15 13:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A221", "patient_id": "P016", "patient_name": "Shida","type": "Cleaning",   "date": "2026-03-12 10:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A222", "patient_id": "P017", "patient_name": "Aria", "type": "Filling",    "date": "2026-03-12 11:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A223", "patient_id": "P018", "patient_name": "Nika", "type": "X-Ray",      "date": "2026-03-13 13:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A224", "patient_id": "P019", "patient_name": "Rami", "type": "Cleaning",   "date": "2026-03-14 09:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A225", "patient_id": "P020", "patient_name": "Tina", "type": "Root Canal", "date": "2026-03-10 15:00", "doctor": "Dr. Reza Noor",  "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A226", "patient_id": "P021", "patient_name": "Sami", "type": "Filling",    "date": "2026-03-15 09:00", "doctor": "Dr. Emma Clark", "duration_minutes": 60, "status": "CONFIRMED"},
    {"appointment_id": "A227", "patient_id": "P016", "patient_name": "Shida","type": "X-Ray",      "date": "2026-03-13 15:00", "doctor": "Dr. Sara Kim",   "duration_minutes": 60, "status": "CONFIRMED"},
]

known_patients = {"P001", "P002", "P003", "P004", "P005", "P006", "P007", "P008", "P009", "P010", "P011", "P012", "P013", "P014", "P015", "P016", "P017", "P018", "P019", "P020", "P021"}
patient_passwords = {
    "P001": "123",
    "P002": "123",
    "P003": "123",
    "P004": "123",
    "P005": "123",
    "P006": "123",
    "P007": "123",
    "P008": "123",
    "P009": "123",
    "P010": "123",
    "P011": "123",
    "P012": "123",
    "P013": "123",
    "P014": "123",
    "P015": "123",
    "P016": "123",
    "P017": "123",
    "P018": "123",
    "P019": "123",
    "P020": "123",
    "P021": "123",
}
known_patient_names = {
    "P001": "Alice Johnson",
    "P002": "Bob Smith",
    "P003": "Carol White",
    "P004": "David Lee",
    "P005": "Mina Chen",
    "P006": "Liam Reed",
    "P007": "Noah West",
    "P008": "Emma Stone",
    "P009": "Mila Hart",
    "P010": "Ethan Cole",
    "P011": "Ava Brooks",
    "P012": "Leo Grant",
    "P013": "Nora Blake",
    "P014": "Owen Shaw",
    "P015": "Ivy Lane",
    "P016": "Shida Ray",
    "P017": "Aria Fox",
    "P018": "Nika Dean",
    "P019": "Rami Cole",
    "P020": "Tina Vale",
    "P021": "Sami Kent",
}
doctor_roster = ["Dr. Sara Kim", "Dr. Reza Noor", "Dr. Emma Clark"]

# Demo patient wallet balances (USD) for cancellation policy simulation.
patient_wallets = {
    pid: 250.0 for pid in known_patients
}

available_slots = [
    "2026-03-09 09:00 | Dr. Sara Kim",
    "2026-03-09 10:00 | Dr. Reza Noor",
    "2026-03-09 14:00 | Dr. Emma Clark",
    "2026-03-10 09:00 | Dr. Emma Clark",
    "2026-03-10 11:00 | Dr. Sara Kim",
    "2026-03-10 15:00 | Dr. Reza Noor",
    "2026-03-11 10:00 | Dr. Reza Noor",
    "2026-03-11 13:00 | Dr. Sara Kim",
    "2026-03-11 14:00 | Dr. Emma Clark",
    "2026-03-12 09:00 | Dr. Sara Kim",
    "2026-03-12 11:00 | Dr. Emma Clark",
    "2026-03-12 15:00 | Dr. Reza Noor",
    "2026-03-13 10:00 | Dr. Emma Clark",
    "2026-03-13 13:00 | Dr. Reza Noor",
    "2026-03-13 14:00 | Dr. Sara Kim",
    "2026-03-14 09:00 | Dr. Reza Noor",
    "2026-03-14 11:00 | Dr. Sara Kim",
    "2026-03-14 15:00 | Dr. Emma Clark",
    "2026-03-15 10:00 | Dr. Sara Kim",
    "2026-03-15 13:00 | Dr. Reza Noor",
    "2026-03-09 11:00 | Dr. Sara Kim",
    "2026-03-10 14:00 | Dr. Reza Noor",
    "2026-03-11 15:00 | Dr. Emma Clark",
    "2026-03-12 10:00 | Dr. Reza Noor",
    "2026-03-13 15:00 | Dr. Sara Kim",
    "2026-03-15 09:00 | Dr. Emma Clark",
]

prep_instructions = {
    "Cleaning":   "Please brush and floss before your appointment. Avoid eating 1 hour before. No special prep needed.",
    "Root Canal": "Eat a light meal before your appointment. Avoid alcohol 24 hours before. Arrange a ride home if needed. Take any prescribed pre-medication as directed.",
    "Filling":    "Eat normally before your appointment. Avoid very hot or cold foods for 24 hours after. Numbness may last 2-3 hours after the procedure.",
    "X-Ray":      "No special preparation needed. Please inform us if you are pregnant. Remove any jewelry or metal objects from your head/neck area.",
    "Default":    "Please arrive 10 minutes early. Bring your insurance card and a valid ID. Contact us if you have any questions before your visit.",
}

ESCALATION_TEMPLATE = (
    "URGENT: Based on what you described, this may be a medical emergency. "
    "Please seek IMMEDIATE medical care. Call 911 or go to the nearest emergency room NOW. "
    "Do NOT wait for a dental appointment. Our clinic cannot provide emergency medical treatment. "
    "Your safety is the priority."
)

def get_appointment(appointment_id, patient_id):
    for a in appointments:
        if a["appointment_id"] == appointment_id and a["patient_id"] == patient_id:
            return a
    return None

def cancel_appointment(appointment_id, patient_id):
    for a in appointments:
        if a["appointment_id"] == appointment_id and a["patient_id"] == patient_id:
            a["status"] = "CANCELLED"
            return True
    return False

def _parse_slot(slot_str):
    # Format: "YYYY-MM-DD HH:MM | Doctor Name"
    if "|" in slot_str:
        date_part, doctor_part = slot_str.split("|", 1)
        return date_part.strip(), doctor_part.strip()
    return slot_str, ""

def reschedule_appointment(appointment_id, patient_id, new_date):
    for a in appointments:
        if a["appointment_id"] == appointment_id and a["patient_id"] == patient_id:
            slot_date, slot_doctor = _parse_slot(new_date)
            a["date"] = slot_date
            if slot_doctor:
                a["doctor"] = slot_doctor
            a["status"] = "RESCHEDULED"
            return True
    return False

def is_slot_available(date_str):
    return date_str in available_slots

def get_prep_instructions(appointment_type):
    return prep_instructions.get(appointment_type, prep_instructions["Default"])

def authenticate_patient(patient_id):
    return patient_id in known_patients


def authenticate_patient_password(patient_id, password):
    return patient_passwords.get(patient_id) == password


def reset_patient_password(patient_id):
    if patient_id not in known_patients:
        return ""
    temp_password = f"TEMP-{patient_id[-3:]}-2026"
    patient_passwords[patient_id] = temp_password
    return temp_password


def get_patient_balance(patient_id):
    return float(patient_wallets.get(patient_id, 0.0))


def apply_cancellation_fee(patient_id, amount=50.0):
    current = get_patient_balance(patient_id)
    new_balance = max(0.0, current - float(amount))
    patient_wallets[patient_id] = new_balance
    return new_balance
