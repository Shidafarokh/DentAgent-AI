# middleware/config.py
# Middleware wrappers used by the LangGraph workflow
#
# Two middleware components are implemented here:
#
#  1. ModelRetryMiddleware  – wraps any LLM call.  If the call raises an
#     exception it retries ONCE (max_retries=1) then re-raises.
#
#  2. HumanInTheLoopMiddleware – pauses execution after DraftGenerationNode
#     and waits for a human reviewer decision (approve / edit / rewrite).
#     In CLI mode the pause is resolved interactively.
#     In Streamlit mode the state is stored and the reviewer panel resolves it.

import time
from typing import Callable, Any
from utils.logging import get_logger

logger = get_logger("Middleware")

# ── 1. ModelRetryMiddleware ────────────────────────────────────────────────────

class ModelRetryMiddleware:
    """
    Wraps an LLM callable.
    Retries the call ONCE on any exception, then re-raises.
    max_retries is hard-coded to 1 per project spec.
    """

    def __init__(self, llm_callable: Callable, max_retries: int = 1):
        self.llm_callable = llm_callable
        self.max_retries = max_retries

    def invoke(self, prompt: str, **kwargs) -> Any:
        attempts = 0
        last_error = None
        while attempts <= self.max_retries:
            try:
                logger.info(f"ModelRetryMiddleware: attempt {attempts + 1}")
                result = self.llm_callable(prompt, **kwargs)
                return result
            except Exception as e:
                last_error = e
                attempts += 1
                if attempts <= self.max_retries:
                    logger.warning(f"ModelRetryMiddleware: call failed ({e}), retrying...")
                    time.sleep(0.5)
        logger.error(f"ModelRetryMiddleware: all attempts failed. Last error: {last_error}")
        raise last_error


# ── 2. HumanInTheLoopMiddleware ───────────────────────────────────────────────

class HumanInTheLoopMiddleware:
    """
    Pauses the workflow after DraftGenerationNode.

    How it works:
      - pause()  stores the draft in state and sets human_action = "PENDING"
      - resume() accepts the reviewer's decision:
            "approve"  → use draft as-is
            "edit"     → use edited_response from state
            "rewrite"  → discard draft, trigger DraftGenerationNode again
      - The actual pause/resume bridge is implemented differently per interface:
            CLI       → blocking input() call inside cli.py
            Streamlit → st.session_state persistence across reruns
    """

    def pause(self, state: dict) -> dict:
        """Mark state as waiting for human review."""
        state["human_action"] = "PENDING"
        logger.info("HumanInTheLoopMiddleware: paused – waiting for reviewer decision.")
        return state

    def resume(self, state: dict, decision: str, edited_text: str = "") -> dict:
        """
        Apply reviewer decision to state.
        decision: "approve" | "edit" | "rewrite"
        """
        decision = decision.strip().lower()
        if decision == "approve":
            state["human_action"] = "approve"
            state["final_response"] = state.get("draft_response", "")
            logger.info("HumanInTheLoopMiddleware: approved by reviewer.")
        elif decision == "edit":
            state["human_action"] = "edit"
            state["final_response"] = edited_text or state.get("draft_response", "")
            state["edited_response"] = state["final_response"]
            logger.info("HumanInTheLoopMiddleware: edited by reviewer.")
        elif decision == "rewrite":
            state["human_action"] = "rewrite"
            state["draft_response"] = ""
            state["final_response"] = ""
            logger.info("HumanInTheLoopMiddleware: rewrite requested by reviewer.")
        else:
            logger.warning(f"HumanInTheLoopMiddleware: unknown decision '{decision}', defaulting to approve.")
            state["human_action"] = "approve"
            state["final_response"] = state.get("draft_response", "")
        return state


# ── Singleton instances used across the app ────────────────────────────────────
hitl_middleware = HumanInTheLoopMiddleware()
