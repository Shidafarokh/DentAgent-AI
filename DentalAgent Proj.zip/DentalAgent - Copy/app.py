from __future__ import annotations

import json
import random
from datetime import date, datetime, timedelta
from html import escape

from dotenv import load_dotenv
import streamlit as st

from data.store import (
    apply_cancellation_fee,
    authenticate_patient_password,
    available_slots,
    appointments,
    doctor_roster,
    known_patient_names,
    reset_patient_password,
)
from graph.workflow import run_workflow
from utils.masking import mask_appointment_id, mask_patient_id, mask_state_for_trace

load_dotenv()

st.set_page_config(
    page_title="DentalAgent AI",
    page_icon=":tooth:",
    layout="wide",
    initial_sidebar_state="collapsed",
)


NORMAL_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700;800&display=swap');
    :root {
        --bg: #f0f4f8;
        --surface: #ffffff;
        --surface-soft: #f9fafb;
        --border: #e5e7eb;
        --text: #1a1a2e;
        --text-soft: #6b7280;
        --title: #1a1a2e;
        --primary: #2d6a4f;
        --primary-hover: #255a43;
        --chip-bg: #f9fafb;
        --chip-border: #e5e7eb;
        --chip-text: #1a1a2e;
        --danger: #991b1b;
        --danger-bg: #fee2e2;
        --shadow-sm: 0 6px 18px rgba(15, 23, 42, 0.06);
        --shadow-md: 0 10px 30px rgba(15, 23, 42, 0.08);
    }

    .stApp {
        font-family: "DM Sans", "Segoe UI", sans-serif;
        background:
            radial-gradient(900px 460px at 8% -10%, #e9eefc 0%, transparent 62%),
            radial-gradient(820px 460px at 100% 0%, #e7f2ef 0%, transparent 60%),
            linear-gradient(180deg, #f4f7fb 0%, var(--bg) 48%, #eef2f8 100%) !important;
        color: var(--text) !important;
    }

    .stApp, .stApp p, .stApp label, .stApp div, .stMarkdown {
        color: var(--text) !important;
    }

    .block-container {
        padding-top: 1.1rem !important;
        padding-bottom: 1.4rem !important;
    }

    div[data-testid="stVerticalBlock"] > div {
        row-gap: 20px;
    }

    h1, h2, h3, h4 {
        color: var(--title) !important;
        letter-spacing: -0.01em;
        font-weight: 700 !important;
    }
    h3 { font-size: 1.1rem !important; }

    hr {
        border: 0;
        border-top: 1px solid #e5e7eb;
        margin: 0.8rem 0 1.2rem 0;
    }

    .stTabs [data-baseweb="tab-list"] {
        background: transparent;
        border: none;
        border-bottom: 1px solid #e5e7eb;
        border-radius: 0;
        padding: 2px 0 0 0;
        gap: 1.1rem;
    }

    .stTabs [data-baseweb="tab"] {
        border-radius: 10px 10px 0 0;
        font-weight: 800;
        color: var(--text-soft) !important;
        background: #f7f9fc;
        border: 1px solid #e5e7eb;
        border-bottom: 3px solid transparent;
        padding: 0.5rem 0.9rem 0.45rem 0.9rem;
        border-bottom: 3px solid transparent;
        letter-spacing: 0.01em;
    }

    .stTabs [aria-selected="true"] {
        background: #ffffff !important;
        color: var(--title) !important;
        border: 1px solid #e5e7eb !important;
        border-bottom: 3px solid #e63946 !important;
        box-shadow: 0 6px 18px rgba(15, 23, 42, 0.06);
    }

    div[data-testid="stVerticalBlockBorderWrapper"] {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 16px;
        box-shadow: var(--shadow-md);
        padding: 24px;
    }

    div[data-testid="stVerticalBlockBorderWrapper"]:hover {
        box-shadow: 0 12px 34px rgba(15, 23, 42, 0.1);
        transform: translateY(-1px);
        transition: all 0.2s ease;
    }

    .stTextInput > div > div > input,
    .stSelectbox > div > div,
    .stTextArea textarea,
    .stDateInput input {
        background-color: #f9fafb !important;
        border: 1px solid #e5e7eb !important;
        border-radius: 12px !important;
        color: #1a1a2e !important;
    }

    .stButton > button,
    .stTextInput input,
    .stTextArea textarea,
    .stSelectbox [data-baseweb="select"],
    .stDateInput input {
        transition: all 0.2s ease !important;
    }

    .stButton > button[kind="secondary"] {
        background-color: #f3f4f6 !important;
        color: #374151 !important;
        border-radius: 12px !important;
        border: 1px solid #e5e7eb !important;
        font-weight: 700 !important;
        padding: 0.52rem 0.9rem !important;
    }

    .stButton > button[kind="secondary"]:hover {
        transform: translateY(-1px);
    }

    .stButton > button[kind="primary"] {
        background-color: #2d6a4f !important;
        color: white !important;
        border-radius: 12px !important;
        border: none !important;
        font-weight: 700 !important;
        padding: 0.56rem 0.95rem !important;
    }

    .stButton > button[kind="primary"]:hover {
        background-color: #255a43 !important;
        transform: translateY(-1px);
    }

    button[aria-label="✗ Cancel"],
    button[aria-label="Submit NO"],
    button[aria-label="Submit NO - Reject"] {
        background-color: #e63946 !important;
        color: #ffffff !important;
        border: none !important;
    }

    button[aria-label="✗ Cancel"]:hover,
    button[aria-label="Submit NO"]:hover,
    button[aria-label="Submit NO - Reject"]:hover {
        background-color: #c1121f !important;
        transform: translateY(-1px);
    }

    button[aria-label="Login"] {
        background-color: #2d6a4f !important;
        color: #ffffff !important;
        border: none !important;
    }
    button[aria-label="Continue"] {
        background-color: #2d6a4f !important;
        color: #ffffff !important;
        border: none !important;
    }
    button[aria-label="Accept"] {
        background-color: #2d6a4f !important;
        color: #ffffff !important;
        border: none !important;
    }
    button[aria-label="Reject"] {
        background-color: #e63946 !important;
        color: #ffffff !important;
        border: none !important;
    }

    button[aria-label="✏️ Edit & Send"] {
        background-color: #f59e0b !important;
        color: #ffffff !important;
        border: none !important;
    }

    button[aria-label="🔄 Rewrite"] {
        background-color: #64748b !important;
        color: #ffffff !important;
        border: none !important;
    }

    .panel-card {
        background: var(--surface);
        border-radius: 16px;
        padding: 18px 18px 16px 18px;
        border: 1px solid var(--border);
        box-shadow: var(--shadow-sm);
        margin-bottom: 16px;
    }

    .request-card {
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 14px;
        box-shadow: var(--shadow-sm);
    }

    .request-head {
        font-size: 13px;
        font-weight: 800;
        color: #111827;
        margin-bottom: 8px;
    }

    .request-grid {
        display: grid;
        grid-template-columns: 180px 1fr;
        gap: 8px 12px;
        margin-top: 4px;
        font-size: 14px;
    }

    .request-label {
        color: #667085;
        font-weight: 700;
    }

    .request-value {
        color: #111827;
        font-weight: 600;
    }

    .request-note {
        background: #f8fbff;
        border: 1px solid #dbe4f1;
        border-radius: 10px;
        padding: 10px 12px;
        color: #334155;
        font-weight: 500;
        margin-top: 10px;
        white-space: pre-wrap;
    }

    .badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 12px;
    }

    .badge-ready { background: #d1fae5; color: #065f46; }
    .badge-pending { background: #e5e7eb; color: #374151; }
    .badge-need { background: #fef3c7; color: #92400e; }
    .badge-escalate { background: #fee2e2; color: #991b1b; }
    .badge-failed { background: #f3f4f6; color: #374151; }

    .escalation-box {
        background: var(--danger-bg) !important;
        border: 1px solid #fecdca !important;
        border-radius: 12px;
        padding: 14px;
        color: var(--danger) !important;
        font-weight: 700;
    }

    .warn { color: var(--danger) !important; font-weight: 700; }

    .run-id {
        font-size: 11px;
        color: #667085;
        font-family: monospace;
    }

    .trace-box {
        background: #f8fafd;
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 12px;
        font-family: monospace;
        font-size: 12px;
        color: #334155;
        max-height: 300px;
        overflow-y: auto;
    }

    .slot-cal-wrap {
        border: 1px solid var(--border);
        border-radius: 14px;
        overflow-x: auto;
        background: var(--surface);
        padding: 9px;
        box-shadow: var(--shadow-sm);
    }

    .slot-cal {
        border-collapse: collapse;
        width: 100%;
        min-width: 760px;
        font-size: 13px;
    }

    .slot-cal th, .slot-cal td {
        border: 1px solid #e3e9f1;
        padding: 8px 10px;
        vertical-align: top;
    }

    .slot-cal th {
        background: linear-gradient(180deg, #f8fbff 0%, #eff5fb 100%);
        color: #334155;
        text-align: center;
        font-weight: 700;
    }

    .slot-time {
        background: #f8fbff;
        font-weight: 700;
        color: #334155;
        width: 92px;
        white-space: nowrap;
    }

    .slot-free {
        background: var(--chip-bg);
        color: var(--chip-text);
        border-radius: 7px;
        padding: 4px 8px;
        display: inline-block;
        border: 1px solid var(--chip-border);
        font-weight: 700;
    }

    .slot-doc {
        border-radius: 7px;
        padding: 4px 8px;
        display: inline-block;
        border: 1px solid;
        font-weight: 700;
        margin-bottom: 4px;
        font-size: 12px;
        line-height: 1.25;
    }

    .slot-doc-free {
        background:
            repeating-linear-gradient(
                -45deg,
                #fff6dc,
                #fff6dc 6px,
                #f6e9bb 6px,
                #f6e9bb 12px
            );
        color: #8a5a00;
        border-color: #e8d08e;
    }

    .slot-doc-busy {
        background: #e9f8ef;
        color: #106d43;
        border-color: #b9e6cc;
    }

    .slot-empty { color: #98a2b3; }

    .slot-legend {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
        margin: 0.2rem 0 0.45rem 0;
    }

    .slot-legend-item {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 5px 10px;
        border: 1px solid #dde6f2;
        border-radius: 999px;
        background: #f8fbff;
        font-size: 12px;
        font-weight: 700;
        color: #475467;
    }

    .occ-head {
        background: linear-gradient(180deg, #f8fbff 0%, #eef3fa 100%);
        border: 1px solid #dbe4f0;
        border-radius: 10px;
        text-align: center;
        font-weight: 700;
        padding: 6px;
        min-height: 38px;
        font-size: 13px;
    }

    .occ-time {
        background: #f8fbff;
        border: 1px solid #dbe4f0;
        border-radius: 10px;
        text-align: center;
        font-weight: 700;
        padding: 6px 4px;
        min-height: 38px;
        font-size: 13px;
    }

    .occ-empty-cell {
        background: #fcfdff;
        border: 1px solid #e3e9f3;
        border-radius: 10px;
        text-align: center;
        color: #98a2b3;
        padding: 6px 4px;
        min-height: 38px;
        font-size: 12px;
    }

    .occ-detail {
        margin-top: 12px;
        background: linear-gradient(180deg, #eff4fb 0%, #e9f1fb 100%);
        border: 1px solid #d4deeb;
        border-radius: 14px;
        padding: 15px;
        animation: occFade 220ms ease-out;
        box-shadow: var(--shadow-sm);
    }

    .occ-chip {
        display: inline-block;
        border-radius: 8px;
        padding: 4px 8px;
        border: 1px solid #cfd8e6;
        background: #f8fbff;
        color: #0f2a4d;
        font-weight: 700;
        font-size: 12px;
        line-height: 1.2;
        white-space: nowrap;
    }

    .occ-chip-confirmed {
        background: #e8f7ef;
        border-color: #b8e5ca;
        color: #0f7a45;
    }

    .occ-chip-cancelled {
        background: #fdecec;
        border-color: #f6c7c4;
        color: #b42318;
    }

    .occ-chip-rescheduled {
        background: #fff6dd;
        border-color: #f4df9a;
        color: #9a6700;
    }

    .top-shell {
        background:
            radial-gradient(620px 240px at 0% 0%, #dff2ea 0%, transparent 65%),
            radial-gradient(560px 260px at 100% 0%, #e4ecff 0%, transparent 60%),
            linear-gradient(120deg, #ffffff 0%, #f8fbff 52%, #f4faf6 100%);
        border: 1px solid #dbe6f1;
        border-radius: 20px;
        padding: 1.2rem 1.3rem 1.1rem 1.3rem;
        box-shadow: 0 14px 36px rgba(15, 23, 42, 0.11);
        margin-bottom: 0.95rem;
        position: relative;
        overflow: hidden;
    }

    .top-shell::after {
        content: "";
        position: absolute;
        right: -32px;
        top: -32px;
        width: 220px;
        height: 220px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(45,106,79,0.17) 0%, rgba(45,106,79,0.0) 72%);
        pointer-events: none;
    }

    .top-grid {
        display: grid;
        grid-template-columns: 1.6fr 1fr;
        gap: 14px;
        align-items: center;
    }

    .top-title {
        margin: 0;
        font-size: 2rem;
        line-height: 1.1;
        font-weight: 800;
        color: #1a1a2e;
    }

    .top-sub {
        margin: 0.2rem 0 0 0;
        color: #475467;
        font-weight: 500;
        font-size: 0.95rem;
    }

    .top-kpis {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
    }

    .top-kpi {
        border-radius: 12px;
        border: 1px solid #d7e2ee;
        background: rgba(255, 255, 255, 0.86);
        padding: 10px 12px;
    }

    .top-kpi-label {
        font-size: 11px;
        font-weight: 700;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }

    .top-kpi-value {
        font-size: 1.15rem;
        font-weight: 800;
        color: #1a1a2e;
        margin-top: 2px;
    }

    .status-legend {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 12px;
    }

    .status-legend span {
        border-radius: 999px;
        padding: 5px 10px;
        border: 1px solid #e5e7eb;
        font-size: 12px;
        font-weight: 700;
    }

    .legend-confirmed { background: #d1fae5; color: #065f46; border-color: #a7f3d0; }
    .legend-cancelled { background: #fee2e2; color: #991b1b; border-color: #fecaca; }
    .legend-rescheduled { background: #fef3c7; color: #92400e; border-color: #fde68a; }

    .patient-stepper {
        display: grid;
        grid-template-columns: repeat(5, minmax(0, 1fr));
        gap: 10px;
        margin: 12px 0 18px 0;
    }

    .patient-step {
        border: 1px solid #e5e7eb;
        background: #f9fafb;
        border-radius: 12px;
        padding: 9px 10px;
        text-align: center;
        font-size: 12px;
        font-weight: 700;
        color: #6b7280;
    }

    .patient-step.active {
        background: #ecfdf5;
        border-color: #a7f3d0;
        color: #065f46;
    }

    .section-chip {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 800;
        color: #1a1a2e;
        background: #eef2ff;
        border: 1px solid #dbeafe;
        letter-spacing: 0.03em;
        margin-bottom: 6px;
        text-transform: uppercase;
    }

    .appt-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
        gap: 12px;
    }

    .appt-card {
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 12px;
        box-shadow: var(--shadow-sm);
        transition: all 0.2s ease;
    }

    .appt-card:hover {
        transform: translateY(-1px);
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.1);
    }

    .appt-meta {
        font-size: 12px;
        color: #6b7280;
        margin-top: 2px;
    }

    .appt-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
    }

    .patient-table-wrap {
        border: 1px solid var(--border);
        border-radius: 14px;
        overflow: hidden;
        background: var(--surface);
        box-shadow: var(--shadow-sm);
    }

    .patient-table-scroll {
        max-height: 268px;
        overflow-y: auto;
    }

    .patient-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }

    .patient-table th,
    .patient-table td {
        border-bottom: 1px solid #e8edf5;
        padding: 10px 12px;
        text-align: left;
        vertical-align: middle;
    }

    .patient-table th {
        background: linear-gradient(180deg, #f8fbff 0%, #eff5fb 100%);
        color: #334155;
        font-weight: 700;
    }

    .status-pill {
        display: inline-block;
        border-radius: 999px;
        padding: 3px 10px;
        font-size: 12px;
        font-weight: 700;
        border: 1px solid transparent;
    }

    .status-confirmed {
        background: #e8f7ef;
        color: #0f7a45;
        border-color: #b8e5ca;
    }

    .status-cancelled {
        background: #fdecec;
        color: #b42318;
        border-color: #f6c7c4;
    }

    .status-rescheduled {
        background: #fff6dd;
        color: #9a6700;
        border-color: #f4df9a;
    }

    .auth-hero {
        background: linear-gradient(130deg, #1b5e43 0%, #2d6a4f 48%, #3a8a67 100%);
        border-radius: 16px;
        padding: 16px 18px;
        border: 1px solid #2f7a5b;
        box-shadow: var(--shadow-md);
        margin-bottom: 14px;
        color: #ecfff5 !important;
    }

    .auth-hero h4 {
        margin: 0 0 6px 0;
        color: #ffffff !important;
        font-size: 1.08rem;
        font-weight: 800;
    }

    .auth-hero p {
        margin: 0;
        color: #d9f8e9 !important;
        font-size: 0.9rem;
    }

    .stMultiSelect [data-baseweb="tag"] {
        background: #d1fae5 !important;
        border: 1px solid #a7f3d0 !important;
        color: #065f46 !important;
    }

    .stMultiSelect [data-baseweb="tag"] svg {
        color: #065f46 !important;
    }

    .auth-pill-row {
        margin-top: 10px;
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .auth-pill {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.14);
        border: 1px solid rgba(255, 255, 255, 0.24);
        color: #f8fbff !important;
        font-size: 11px;
        font-weight: 700;
    }

    .auth-note {
        background: #f7f9fc;
        border: 1px solid #dbe4f1;
        border-radius: 12px;
        padding: 10px 12px;
        color: #475467 !important;
        font-size: 12px;
    }

    @media (max-width: 1024px) {
        div[data-testid="stVerticalBlockBorderWrapper"] {
            padding: 18px;
        }
        .slot-cal { min-width: 680px; }
        .top-grid { grid-template-columns: 1fr; }
    }

    @keyframes occFade {
        from { opacity: 0; transform: translateY(-6px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
"""

ESCALATION_CSS = """
<style>
    .stApp { background-color: #fff0f0 !important; }
    .escalation-box {
        background: #fee2e2 !important;
        border: 1px solid #fecaca !important;
    }
</style>
"""


def apply_theme(escalation: bool = False) -> None:
    st.markdown(ESCALATION_CSS if escalation else NORMAL_CSS, unsafe_allow_html=True)


def init_session() -> None:
    defaults = {
        "step": "login",
        "patient_id": "",
        "patient_name": "",
        "intent": "",
        "appointment_id": "",
        "requested_date": "",
        "reschedule_choice": "",
        "raw_input": "",
        "reviewer_reschedule_accept": "yes",
        "confirmed": False,
        "draft_result": None,
        "final_result": None,
        "human_decision": "approve",
        "human_edited": "",
        "debug_mode": False,
        "chat_history": [],
        "selected_reviewer_appointment_id": "",
        "last_reminder_message": "",
        "active_panel": "Patient Panel",
        "cancellation_policy_ack": "No",
        "cancellation_fee_applied": False,
        "cancellation_fee_notice": "",
        "cancellation_fee_request_key": "",
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


def status_badge(status: str) -> str:
    cls_map = {
        "READY": "badge-ready",
        "PENDING": "badge-pending",
        "NEED_INFO": "badge-need",
        "ESCALATE": "badge-escalate",
        "FAILED": "badge-failed",
    }
    cls = cls_map.get(status, "badge-pending")
    return f'<span class="badge {cls}">{status}</span>'


def add_chat(role: str, message: str) -> None:
    st.session_state.chat_history.append({"role": role, "message": message})


def detect_emergency_text(text: str) -> bool:
    if not text:
        return False
    t = text.lower()
    emergency_terms = [
        "emergency",
        "bleeding",
        "severe bleeding",
        "uncontrolled bleeding",
        "trouble breathing",
        "difficulty breathing",
        "swelling",
        "severe pain",
        "chest pain",
        "911",
        "urgent",
    ]
    return any(term in t for term in emergency_terms)


def infer_intent_from_text(text: str) -> str:
    if not text:
        return "unknown"
    t = text.lower().strip()
    if any(x in t for x in ["cancel appointment", "cancel my appointment", "i want to cancel", "cancel"]):
        return "cancel"
    if any(
        x in t
        for x in [
            "reschedule appointment",
            "reschedule",
            "change appointment",
            "move appointment",
            "as soon as possible",
            "earliest",
            "i want to see doctor",
            "see doctor as soon as possible",
        ]
    ):
        return "reschedule"
    if any(x in t for x in ["prep", "preparation", "prepare", "instructions", "before appointment"]):
        return "prep_instructions"
    return "unknown"


def get_patient_appointment(patient_id: str, appointment_id: str) -> dict | None:
    for appt in appointments:
        if appt.get("patient_id") == patient_id and appt.get("appointment_id") == appointment_id:
            return appt
    return None


def is_cancellation_within_48h(patient_id: str, appointment_id: str) -> bool:
    # Current requested demo assumption: all cancellations are within 48 hours.
    return True


def _parse_slot(slot: str) -> tuple[str, str, str]:
    dt_part, doctor = slot, ""
    if "|" in slot:
        dt_part, doctor = slot.split("|", 1)
        doctor = doctor.strip()
    dt_part = dt_part.strip()
    date_str, time_str = dt_part.split(" ", 1)
    return date_str, time_str, doctor


def get_week_slots(slots: list[str], start_date: str = "2026-03-09", end_date: str = "2026-03-15") -> list[str]:
    start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
    end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
    in_week = []
    for s in slots:
        d, _, _ = _parse_slot(s)
        day = datetime.strptime(d, "%Y-%m-%d").date()
        if start_dt <= day <= end_dt:
            in_week.append(s)
    return sorted(in_week)


def _occupied_doctor_keys() -> set[tuple[str, str, str]]:
    occupied = set()
    for appt in appointments:
        if appt.get("status", "").upper() == "CANCELLED":
            continue
        date_part, time_part = appt.get("date", "").split(" ", 1)
        doctor = appt.get("doctor", "").strip()
        if date_part and time_part and doctor:
            occupied.add((date_part, time_part, doctor))
    return occupied


def get_free_week_slots(slots: list[str], start_date: str = "2026-03-09", end_date: str = "2026-03-15") -> list[str]:
    occupied = _occupied_doctor_keys()
    week_slots = get_week_slots(slots, start_date=start_date, end_date=end_date)
    free_slots = []
    for s in week_slots:
        d, t, dr = _parse_slot(s)
        if not dr:
            continue
        if (d, t, dr) not in occupied:
            free_slots.append(s)
    return free_slots


def get_availability_board_slots(slots: list[str], start_date: str = "2026-03-09", end_date: str = "2026-03-15") -> list[str]:
    start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
    end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
    merged = set(get_week_slots(slots, start_date=start_date, end_date=end_date))
    for appt in appointments:
        date_part, time_part = appt.get("date", "").split(" ", 1)
        doctor = appt.get("doctor", "").strip()
        if not date_part or not time_part or not doctor:
            continue
        day = datetime.strptime(date_part, "%Y-%m-%d").date()
        if start_dt <= day <= end_dt:
            merged.add(f"{date_part} {time_part} | {doctor}")
    return sorted(merged)


def get_patient_appointments(patient_id: str) -> list[dict]:
    patient_rows = [a for a in appointments if a.get("patient_id", "") == patient_id]
    return sorted(patient_rows, key=lambda a: datetime.strptime(a["date"], "%Y-%m-%d %H:%M"))


def render_patient_upcoming_appointments(patient_id: str) -> None:
    st.markdown("### Your Upcoming Appointments")
    rows = get_patient_appointments(patient_id)
    if not rows:
        st.info("No appointment found for this Patient ID.")
        return

    status_label_map = {"CONFIRMED": "Confirmed", "CANCELLED": "Cancelled", "RESCHEDULED": "Rescheduled"}
    status_class_map = {
        "CONFIRMED": "status-confirmed",
        "CANCELLED": "status-cancelled",
        "RESCHEDULED": "status-rescheduled",
    }
    card_rows = []
    for a in rows:
        dt = datetime.strptime(a["date"], "%Y-%m-%d %H:%M")
        raw_status = a.get("status", "CONFIRMED").upper()
        status_label = status_label_map.get(raw_status, raw_status.title())
        status_cls = status_class_map.get(raw_status, "status-confirmed")
        card_rows.append(
            "<div class='appt-card'>"
            "<div class='appt-head'>"
            f"<strong>{escape(a.get('appointment_id', ''))}</strong>"
            f"<span class='status-pill {status_cls}'>{escape(status_label)}</span>"
            "</div>"
            f"<div class='appt-meta'>{escape(a.get('doctor', ''))}</div>"
            f"<div class='appt-meta'>{escape(a.get('type', ''))}</div>"
            f"<div class='appt-meta'>{dt.strftime('%Y-%m-%d')} at {dt.strftime('%H:%M')}</div>"
            "</div>"
        )

    html = f"<div class='appt-grid'>{''.join(card_rows)}</div>"
    st.markdown(html, unsafe_allow_html=True)


def render_slots_calendar(
    slots: list[str],
    title: str,
    show_occupancy: bool = False,
    start_date: str = "2026-03-09",
    end_date: str = "2026-03-15",
    time_rows: list[str] | None = None,
) -> None:
    if not slots:
        st.markdown("*No available slots.*")
        return

    parsed = [_parse_slot(s) for s in sorted(slots)]
    start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
    end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
    dates = []
    curr = start_dt
    while curr <= end_dt:
        dates.append(curr.strftime("%Y-%m-%d"))
        curr += timedelta(days=1)
    times = time_rows or ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00"]
    cell_map: dict[tuple[str, str], list[str]] = {}
    for d, t, dr in parsed:
        key = (d, t)
        cell_map.setdefault(key, [])
        if dr:
            cell_map[key].append(dr)
    occupied = _occupied_doctor_keys() if show_occupancy else set()

    header = "".join([f"<th>{datetime.strptime(d, '%Y-%m-%d').strftime('%a %b %d')}</th>" for d in dates])
    rows = []
    for t in times:
        cols = []
        for d in dates:
            docs = cell_map.get((d, t), [])
            if docs:
                labels_parts = []
                for x in sorted(set(docs)):
                    if show_occupancy:
                        state_cls = "slot-doc-busy" if (d, t, x) in occupied else "slot-doc-free"
                        labels_parts.append(f"<span class='slot-doc {state_cls}'>{x}</span>")
                    else:
                        labels_parts.append(f"<span class='slot-free'>{x}</span>")
                labels = "<br>".join(labels_parts)
                cols.append(f"<td>{labels}</td>")
            else:
                cols.append("<td><span class='slot-empty'>-</span></td>")
        rows.append(f"<tr><td class='slot-time'>{t}</td>{''.join(cols)}</tr>")

    st.markdown(f"**{title}**")
    html = (
        "<div class='slot-cal-wrap'>"
        "<table class='slot-cal'>"
        f"<thead><tr><th>Time</th>{header}</tr></thead>"
        f"<tbody>{''.join(rows)}</tbody>"
        "</table>"
        "</div>"
    )
    st.markdown(html, unsafe_allow_html=True)


def render_reviewer_appointments_calendar() -> None:
    st.markdown("### Weekly Appointment Occupancy")

    all_appts = sorted(appointments, key=lambda a: datetime.strptime(a["date"], "%Y-%m-%d %H:%M"))
    if not all_appts:
        st.markdown("*No appointments available.*")
        return

    time_rows = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00"]
    dates = sorted({a["date"].split(" ")[0] for a in all_appts})

    occ_map: dict[tuple[str, str], list[dict]] = {}
    for appt in all_appts:
        d, t = appt["date"].split(" ", 1)
        if t in time_rows:
            occ_map.setdefault((d, t), []).append(appt)

    header = "".join([f"<th>{datetime.strptime(d, '%Y-%m-%d').strftime('%a %b %d')}</th>" for d in dates])
    rows_html = []
    for t in time_rows:
        cols = []
        for d in dates:
            slots = occ_map.get((d, t), [])
            if not slots:
                cols.append("<td><span class='slot-empty'>-</span></td>")
            else:
                chips = []
                for appt in slots:
                    patient_name = appt.get("patient_name") or known_patient_names.get(appt.get("patient_id", ""), appt.get("patient_id", ""))
                    status = appt.get("status", "CONFIRMED").upper()
                    cls = {
                        "CONFIRMED": "occ-chip-confirmed",
                        "CANCELLED": "occ-chip-cancelled",
                        "RESCHEDULED": "occ-chip-rescheduled",
                    }.get(status, "occ-chip-confirmed")
                    chips.append(f"<span class='occ-chip {cls}'>{escape(patient_name)}</span>")
                cols.append(f"<td>{'<br>'.join(chips)}</td>")
        rows_html.append(f"<tr><td class='slot-time'>{t}</td>{''.join(cols)}</tr>")

    cal_html = (
        "<div class='slot-cal-wrap'>"
        "<table class='slot-cal'>"
        f"<thead><tr><th>Time</th>{header}</tr></thead>"
        f"<tbody>{''.join(rows_html)}</tbody>"
        "</table>"
        "</div>"
    )
    st.markdown(cal_html, unsafe_allow_html=True)

    pickable = [
        (
            a["appointment_id"],
            f"{a['appointment_id']} | {a.get('patient_name') or known_patient_names.get(a.get('patient_id', ''), a.get('patient_id', ''))} | "
            f"{a.get('doctor', '')} | {a['date']}",
        )
        for a in all_appts
    ]
    label_by_id = {pid: label for pid, label in pickable}
    options = [pid for pid, _ in pickable]
    if options:
        current_id = st.session_state.get("selected_reviewer_appointment_id")
        default_index = options.index(current_id) if current_id in options else 0
        picked = st.selectbox(
            "Select appointment to view details:",
            options=options,
            index=default_index,
            format_func=lambda x: label_by_id[x],
            key="occ_selectbox_pick",
        )
        st.session_state.selected_reviewer_appointment_id = picked

    selected_id = st.session_state.get("selected_reviewer_appointment_id", "")
    selected = next((a for a in all_appts if a["appointment_id"] == selected_id), None)
    if not selected:
        return

    start = datetime.strptime(selected["date"], "%Y-%m-%d %H:%M")
    status_map = {"CONFIRMED": "Scheduled", "CANCELLED": "Cancelled", "RESCHEDULED": "Rescheduled"}
    safe_pid = mask_patient_id(selected.get("patient_id", ""))
    patient_name = selected.get("patient_name") or known_patient_names.get(selected.get("patient_id", ""), selected.get("patient_id", ""))

    reminder_text = (
        f"Reminder: Dear {patient_name}, this is a reminder for your upcoming appointment on "
        f"{start.strftime('%Y-%m-%d at %H:%M')} with {selected.get('doctor', 'our dentist')}. "
        "Please arrive 10 minutes early."
    )
    reminder_key = f"reminder_edit_{selected.get('appointment_id', '')}"
    if reminder_key not in st.session_state:
        st.session_state[reminder_key] = reminder_text

    with st.container(border=True):
        st.markdown("<div class='occ-detail'><h4 style='margin:0 0 10px 0; color:#0f172a;'>Appointment Detail</h4>", unsafe_allow_html=True)
        left_col, right_col = st.columns([1.45, 1], gap="large")
        with right_col:
            st.markdown(
                f"""
| Field | Value |
|---|---|
| Appointment ID | `{selected.get('appointment_id', '')}` |
| Patient Name | `{patient_name}` |
| Patient ID | `{safe_pid}` |
| Dentist Name | `{selected.get('doctor', 'N/A')}` |
| Appointment Type | `{selected.get('type', '')}` |
| Date | `{start.strftime('%Y-%m-%d')}` |
| Time | `{start.strftime('%H:%M')}` |
| Status | `{status_map.get(selected.get('status', ''), selected.get('status', ''))}` |
"""
            )
        with left_col:
            edited_text = st.text_area("Reminder message preview", key=reminder_key, height=130)
            if st.button("Send Reminder", key=f"send_occ_rem_{selected.get('appointment_id', '')}", type="primary"):
                st.session_state.last_reminder_message = edited_text
                add_chat("reviewer", f"Reminder sent for {selected.get('appointment_id', '')}")
                st.success("Reminder sent.")
        st.markdown("</div>", unsafe_allow_html=True)


def render_reviewer_patient_table() -> None:
    st.markdown("### Patient Appointment List")
    all_appts = sorted(appointments, key=lambda a: datetime.strptime(a["date"], "%Y-%m-%d %H:%M"))
    if not all_appts:
        st.markdown("*No patient appointments found.*")
        return

    rows = []
    for appt in all_appts:
        patient_id = appt.get("patient_id", "")
        patient_name = appt.get("patient_name") or known_patient_names.get(patient_id, patient_id)
        dt = datetime.strptime(appt["date"], "%Y-%m-%d %H:%M")
        raw_status = appt.get("status", "CONFIRMED").upper()

        status_label_map = {
            "CONFIRMED": "Confirmed",
            "CANCELLED": "Cancelled",
            "RESCHEDULED": "Rescheduled",
        }
        status_class_map = {
            "CONFIRMED": "status-confirmed",
            "CANCELLED": "status-cancelled",
            "RESCHEDULED": "status-rescheduled",
        }

        status_label = status_label_map.get(raw_status, raw_status.title())
        status_cls = status_class_map.get(raw_status, "status-confirmed")

        rows.append(
            "<tr>"
            f"<td>{escape(appt.get('appointment_id', ''))}</td>"
            f"<td>{escape(patient_id)}</td>"
            f"<td>{escape(patient_name)}</td>"
            f"<td>{escape(appt.get('doctor', ''))}</td>"
            f"<td>{escape(appt.get('type', ''))}</td>"
            f"<td>{dt.strftime('%Y-%m-%d')}</td>"
            f"<td>{dt.strftime('%H:%M')}</td>"
            f"<td><span class='status-pill {status_cls}'>{escape(status_label)}</span></td>"
            "</tr>"
        )

    table_html = (
        "<div class='patient-table-wrap'>"
        "<div class='patient-table-scroll'>"
        "<table class='patient-table'>"
        "<thead><tr>"
        "<th>Appointment ID</th>"
        "<th>Patient ID</th>"
        "<th>Patient Name</th>"
        "<th>Dentist</th>"
        "<th>Visit Reason</th>"
        "<th>Date</th>"
        "<th>Time</th>"
        "<th>Status</th>"
        "</tr></thead>"
        f"<tbody>{''.join(rows)}</tbody>"
        "</table>"
        "</div>"
        "</div>"
    )
    st.markdown(table_html, unsafe_allow_html=True)


def render_left_panel() -> None:
    st.markdown("## Patient Portal")

    st.markdown("---")

    if st.session_state.step == "login":
        st.markdown("<span class='section-chip'>Access</span>", unsafe_allow_html=True)
        st.markdown("### Patient Login")
        st.markdown(
            """
<div class="auth-hero">
  <h4>Secure Patient Access</h4>
  <p>Use your Patient ID and password to access appointments, reschedule options, and preparation instructions.</p>
</div>
            """,
            unsafe_allow_html=True,
        )
        with st.form("login_form"):
            pid = st.text_input("Patient ID", placeholder="e.g. P001", max_chars=10)
            password = st.text_input("Password", type="password", placeholder="Enter your password")
            submitted = st.form_submit_button("Login", type="primary")
        if submitted:
            patient_id = pid.strip().upper()
            if not patient_id:
                st.markdown('<span class="warn">Please enter your Patient ID.</span>', unsafe_allow_html=True)
            elif not password:
                st.markdown('<span class="warn">Please enter your password.</span>', unsafe_allow_html=True)
            elif authenticate_patient_password(patient_id, password):
                st.session_state.patient_id = patient_id
                st.session_state.step = "form"
                add_chat("system", f"Patient {mask_patient_id(patient_id)} logged in.")
                st.rerun()
            else:
                st.error("Invalid Patient ID or password.")

        with st.expander("Forgot password?"):
            st.markdown("<div class='auth-note'>Reset password using your Patient ID. A temporary password will be generated for demo use. Current default password for all patients: <b>123</b>.</div>", unsafe_allow_html=True)
            with st.form("forgot_password_form"):
                forgot_pid = st.text_input("Patient ID for reset", placeholder="e.g. P001", max_chars=10)
                reset_submitted = st.form_submit_button("Generate Temporary Password", type="secondary")
            if reset_submitted:
                temp_password = reset_patient_password(forgot_pid.strip().upper())
                if temp_password:
                    st.success(f"Temporary password created: {temp_password}")
                else:
                    st.error("Patient ID not found.")

    elif st.session_state.step == "form":
        st.markdown("<span class='section-chip'>Request</span>", unsafe_allow_html=True)
        st.markdown(f"### Welcome, Patient {mask_patient_id(st.session_state.patient_id)}")
        render_patient_upcoming_appointments(st.session_state.patient_id)
        st.markdown("---")

        with st.form("intent_form"):
            intent = st.selectbox(
                "Request Type",
                ["", "cancel", "reschedule", "prep_instructions"],
                format_func=lambda x: {
                    "": "Select request type...",
                    "cancel": "Cancel Appointment",
                    "reschedule": "Reschedule Appointment",
                    "prep_instructions": "Get Preparation Instructions",
                }[x],
            )

            appt_id = st.text_input("Appointment ID", placeholder="e.g. A201")
            requested_date = ""
            reschedule_choice = ""

            raw_input = st.text_area("Additional Notes (optional)", height=90)

            if intent == "reschedule":
                st.markdown("---")
                board_slots = get_availability_board_slots(available_slots)
                selected_appt = None
                patient_appt_id = appt_id.strip().upper() if appt_id else ""
                if patient_appt_id:
                    selected_appt = next(
                        (
                            a
                            for a in appointments
                            if a.get("appointment_id") == patient_appt_id
                            and a.get("patient_id") == st.session_state.patient_id
                        ),
                        None,
                    )

                doctor_slots: list[str] = []
                suggested_slots: list[str] = []
                if selected_appt:
                    assigned_doctor = selected_appt.get("doctor", "")
                    doctor_slots = [s for s in board_slots if _parse_slot(s)[2] == assigned_doctor]
                    free_doctor_slots = get_free_week_slots(doctor_slots)
                    suggestion_key = f"patient_slot_suggestions_{st.session_state.patient_id}_{patient_appt_id}"
                    if suggestion_key not in st.session_state:
                        if len(free_doctor_slots) > 3:
                            st.session_state[suggestion_key] = random.sample(free_doctor_slots, 3)
                        else:
                            st.session_state[suggestion_key] = free_doctor_slots
                    suggested_slots = list(st.session_state.get(suggestion_key, []))
                    render_slots_calendar(
                        suggested_slots,
                        f"3 Available Options for {assigned_doctor} (Mar 9 - Mar 15)",
                        show_occupancy=True,
                    )
                else:
                    st.info("Enter your valid Appointment ID first to view available slots for your assigned doctor.")

                options = [""]
                choice_labels = {"": "Select one option..."}
                for idx, slot in enumerate(suggested_slots, start=1):
                    key = str(idx)
                    options.append(key)
                    choice_labels[key] = f"{idx}) {slot}"
                options.append("4")
                choice_labels["4"] = "4) None of these, cancel appointment"

                reschedule_choice = st.selectbox(
                    "Suggested new times (choose one):",
                    options=options,
                    format_func=lambda x: choice_labels[x],
                )
                if reschedule_choice in {"1", "2", "3"} and int(reschedule_choice) <= len(suggested_slots):
                    requested_date = suggested_slots[int(reschedule_choice) - 1]

            submitted = st.form_submit_button("Continue", type="primary")

        if submitted:
            inferred_intent = infer_intent_from_text(raw_input)
            resolved_intent = inferred_intent if inferred_intent != "unknown" else intent

            if not intent and inferred_intent == "unknown":
                st.markdown('<span class="warn">Please select a Request Type.</span>', unsafe_allow_html=True)
            elif not appt_id.strip():
                st.markdown('<span class="warn">Please enter your Appointment ID.</span>', unsafe_allow_html=True)
            elif resolved_intent == "reschedule" and intent != "reschedule":
                st.info("Detected reschedule intent from your message. Please set Request Type to Reschedule to choose time options.")
            elif detect_emergency_text(raw_input):
                emergency_msg = (
                    "URGENT: Your message may indicate a medical emergency. "
                    "Please call 911 immediately or go to the nearest emergency room now. "
                    "Do not wait for scheduling or messaging in this app."
                )
                st.session_state.final_result = {
                    "terminal_status": "ESCALATE",
                    "risk_detected": True,
                    "escalation_message": emergency_msg,
                    "final_response": emergency_msg,
                    "timestamp": datetime.now().isoformat(timespec="seconds"),
                    "route_taken": ["patient_input", "emergency_detected"],
                    "execution_trace": [
                        {
                            "time": datetime.now().strftime("%H:%M:%S"),
                            "node": "emergency_guard",
                            "detail": "Emergency phrase detected in patient free-text input. Workflow blocked.",
                        }
                    ],
                }
                st.session_state.draft_result = None
                st.session_state.step = "done"
                add_chat("system", "Emergency guard triggered. Patient instructed to call 911.")
                st.rerun()
            elif resolved_intent == "reschedule" and not reschedule_choice:
                st.markdown('<span class="warn">Please choose one of the 4 options first.</span>', unsafe_allow_html=True)
            else:
                st.session_state.intent = resolved_intent
                st.session_state.appointment_id = appt_id.strip().upper()
                st.session_state.requested_date = requested_date
                st.session_state.reschedule_choice = reschedule_choice
                st.session_state.raw_input = raw_input
                if resolved_intent == "reschedule" and reschedule_choice == "4":
                    st.session_state.intent = "cancel"
                st.session_state.cancellation_policy_ack = "No"
                st.session_state.cancellation_fee_applied = False
                st.session_state.cancellation_fee_notice = ""
                st.session_state.cancellation_fee_request_key = (
                    f"{st.session_state.patient_id}|{st.session_state.appointment_id}|{st.session_state.intent}|"
                    f"{st.session_state.requested_date}"
                )
                st.session_state.step = "confirm"
                st.rerun()

    elif st.session_state.step == "confirm":
        st.markdown("<span class='section-chip'>Confirmation</span>", unsafe_allow_html=True)
        st.markdown("### Confirm Your Request")
        selected_appt = get_patient_appointment(
            st.session_state.patient_id,
            st.session_state.appointment_id,
        )
        current_appt_time = selected_appt.get("date", "N/A") if selected_appt else "N/A"
        is_cancel = st.session_state.intent == "cancel"
        late_cancel = is_cancel and is_cancellation_within_48h(
            st.session_state.patient_id,
            st.session_state.appointment_id,
        )
        cancel_fee = 50.0
        st.markdown(
            f"""
| Field | Value |
|---|---|
| Action | **{st.session_state.intent}** |
| Appointment ID | `{st.session_state.appointment_id}` |
| Current Appointment Time | `{current_appt_time}` |
| New Date | `{st.session_state.requested_date or 'N/A'}` |
"""
        )

        if late_cancel:
            st.warning(
                "Since less than 48 hours remain to your appointment, this cancellation has a $50 fee "
                "and the next availability may move to 2 weeks later. "
                "This fee will be charged to your authorized payment method. Do you still want to cancel?"
            )
            st.session_state.cancellation_policy_ack = st.radio(
                "Do you still want to cancel?",
                options=["No", "Yes"],
                horizontal=True,
                key="cancel_policy_ack_radio",
            )
        elif is_cancel:
            st.info("This cancellation is outside the 48-hour window. No fee will be charged.")

        cols = st.columns(2)
        with cols[0]:
            if st.button("✓ Confirm", use_container_width=True, type="primary"):
                if late_cancel and st.session_state.get("cancellation_policy_ack") != "Yes":
                    st.markdown('<span class="warn">Please choose "Yes" to continue with this late cancellation.</span>', unsafe_allow_html=True)
                    st.stop()
                if late_cancel:
                    request_key = (
                        f"{st.session_state.patient_id}|{st.session_state.appointment_id}|{st.session_state.intent}|"
                        f"{st.session_state.requested_date}"
                    )
                    if (
                        not st.session_state.get("cancellation_fee_applied", False)
                        or st.session_state.get("cancellation_fee_request_key") != request_key
                    ):
                        apply_cancellation_fee(st.session_state.patient_id, cancel_fee)
                        st.session_state.cancellation_fee_applied = True
                        st.session_state.cancellation_fee_request_key = request_key
                        st.session_state.cancellation_fee_notice = (
                            "Late cancellation fee applied: $50.00 charged to authorized payment method."
                        )
                st.session_state.confirmed = True
                _run_draft_workflow()
                st.rerun()
        with cols[1]:
            if st.button("✗ Cancel", use_container_width=True, type="secondary"):
                st.session_state.step = "form"
                st.rerun()

    elif st.session_state.step == "review":
        st.markdown("<span class='section-chip'>Review</span>", unsafe_allow_html=True)
        result = st.session_state.draft_result or {}
        st.markdown("### Awaiting Reviewer Decision")
        if st.session_state.get("cancellation_fee_notice"):
            st.info(st.session_state.get("cancellation_fee_notice"))
        if result.get("risk_detected"):
            st.markdown(f"<div class='escalation-box'>{result.get('escalation_message', '')}</div>", unsafe_allow_html=True)
        elif (st.session_state.get("intent") or result.get("intent")) == "reschedule":
            st.info("Waiting for reviewer approval.")
        else:
            st.markdown("**Draft Response Preview:**")
            st.markdown(f"<div class='panel-card'>{result.get('draft_response', '')}</div>", unsafe_allow_html=True)

    elif st.session_state.step == "done":
        st.markdown("<span class='section-chip'>Complete</span>", unsafe_allow_html=True)
        result = st.session_state.final_result or {}
        status = result.get("terminal_status", "UNKNOWN")
        st.markdown("### Request Complete")
        st.markdown(status_badge(status), unsafe_allow_html=True)
        if st.session_state.get("cancellation_fee_notice"):
            st.info(st.session_state.get("cancellation_fee_notice"))

        if result.get("risk_detected") or status == "ESCALATE":
            st.markdown(f"<div class='escalation-box'>{result.get('escalation_message', '')}</div>", unsafe_allow_html=True)
        else:
            st.markdown(f"<div class='panel-card'>{result.get('final_response', '')}</div>", unsafe_allow_html=True)


def render_right_panel() -> None:
    st.markdown("## Reviewer Panel")

    result = st.session_state.get("draft_result") or {}
    final = st.session_state.get("final_result") or {}

    st.markdown("### Doctor Availability")
    week_start = date(2026, 3, 9)
    week_end = date(2026, 3, 15)
    c1, c2 = st.columns(2)
    with c1:
        with st.container(border=True):
            selected_doctor = st.selectbox("Doctor", doctor_roster, key="review_doctor_select")
            selected_date = st.date_input(
                "Date",
                value=week_start,
                min_value=week_start,
                max_value=week_end,
                key="review_date_select",
            )
    with c2:
        with st.container(border=True):
            selected_times = st.multiselect(
                "Mark available times",
                options=["09:00", "10:00", "11:00", "13:00", "14:00", "15:00"],
                key="review_times_multiselect",
            )
            if st.button("Add Availability", use_container_width=True, type="primary"):
                added = 0
                for t in selected_times:
                    slot = f"{selected_date.strftime('%Y-%m-%d')} {t} | {selected_doctor}"
                    if slot not in available_slots:
                        available_slots.append(slot)
                        added += 1
                if added:
                    st.success(f"{added} slot(s) added.")
                else:
                    st.info("No new slot was added (already exists).")

    st.markdown("**Possible Time Slots:**")
    st.markdown(
        """
<div class="slot-legend">
  <span class="slot-legend-item"><span class="slot-doc slot-doc-busy">Full</span> Doctor present and slot is occupied (booked)</span>
  <span class="slot-legend-item"><span class="slot-doc slot-doc-free">Empty</span> Doctor present and slot is empty (bookable)</span>
</div>
        """,
        unsafe_allow_html=True,
    )
    week_slots = get_availability_board_slots(available_slots)
    render_slots_calendar(week_slots, "Calender (Mar 9 - Mar 15)", show_occupancy=True)
    st.markdown("---")

    st.markdown("### Weekly Patient Visits")
    render_reviewer_appointments_calendar()
    if st.session_state.get("last_reminder_message"):
        st.info(f"Last reminder: {st.session_state.get('last_reminder_message')}")
    st.markdown("---")
    render_reviewer_patient_table()
    st.markdown("---")

    st.session_state.debug_mode = st.toggle("Debug Mode", value=st.session_state.get("debug_mode", False))
    st.markdown("---")

    st.markdown("### Requests")
    if not result:
        st.markdown("*No request yet. Patient must submit a request first.*")
    elif result.get("risk_detected"):
        st.markdown(
            f"<div class='escalation-box'>ESCALATION DETECTED<br><br>{result.get('escalation_message', '')}</div>",
            unsafe_allow_html=True,
        )
    else:
        selected_appt = next(
            (
                a
                for a in appointments
                if a.get("appointment_id") == st.session_state.get("appointment_id")
                and a.get("patient_id") == st.session_state.get("patient_id")
            ),
            None,
        )
        req_patient_name = (
            (selected_appt or {}).get("patient_name")
            or st.session_state.get("patient_name")
            or known_patient_names.get(st.session_state.get("patient_id", ""), st.session_state.get("patient_id", "N/A"))
        )
        req_doctor = (selected_appt or {}).get("doctor", "N/A")
        req_time = (selected_appt or {}).get("date", "N/A")
        req_kind = (result.get("intent") or st.session_state.get("intent", "unknown")).replace("_", " ").title()
        req_text = st.session_state.get("raw_input", "").strip() or "No additional note"
        req_target = st.session_state.get("requested_date", "").strip()
        req_id = result.get("run_id", "1")
        req_appt_id = st.session_state.get("appointment_id", "") or (selected_appt or {}).get("appointment_id", "N/A")
        request_text_block = (
            f"<div class='request-note'>{escape(req_text)}</div>"
            if req_text
            else "<div class='request-note'>No additional note</div>"
        )
        st.markdown(
            f"""
<div class='request-card'>
  <div class='request-head'>Request #1</div>
  <div class='request-grid'>
    <div class='request-label'>Request ID</div><div class='request-value'>{escape(str(req_id))}</div>
    <div class='request-label'>Appointment ID</div><div class='request-value'>{escape(str(req_appt_id))}</div>
    <div class='request-label'>Patient Name</div><div class='request-value'>{escape(str(req_patient_name))}</div>
    <div class='request-label'>Doctor Name</div><div class='request-value'>{escape(str(req_doctor))}</div>
    <div class='request-label'>Current Appointment Time</div><div class='request-value'>{escape(str(req_time))}</div>
    <div class='request-label'>Request Type</div><div class='request-value'>{escape(str(req_kind))}</div>
    <div class='request-label'>Requested New Time</div><div class='request-value'>{escape(req_target or "N/A")}</div>
  </div>
  {request_text_block}
</div>
            """,
            unsafe_allow_html=True,
        )
        st.session_state.human_edited = st.text_area(
            "Response Text (editable):",
            value=st.session_state.get("human_edited", result.get("draft_response", "")),
            height=140,
            key="draft_edit_box",
        )

    if st.session_state.step == "review" and result:
        st.markdown("### Reviewer Decision")
        if result.get("intent") == "reschedule":
            st.caption("Review this request and choose one action.")
            c0, c1, c2 = st.columns([6.3, 1.2, 1.2])
            with c1:
                if st.button("Accept", use_container_width=True, type="primary"):
                    _finalize("approve", reschedule_approved=True)
                    st.rerun()
            with c2:
                if st.button("Reject", use_container_width=True, type="secondary"):
                    _finalize("approve", reschedule_approved=False)
                    st.rerun()
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                if st.button("✅ Approve", use_container_width=True, type="primary"):
                    _finalize("approve")
                    st.rerun()
            with c2:
                if st.button("✏️ Edit & Send", use_container_width=True, type="secondary"):
                    _finalize("edit")
                    st.rerun()
            with c3:
                if st.button("🔄 Rewrite", use_container_width=True, type="secondary"):
                    _finalize("rewrite")
                    st.rerun()

    if final:
        st.markdown("---")
        st.markdown("### Reviewer Decision Result")
        final_status = final.get("terminal_status", "UNKNOWN")
        decision_label = final.get("human_decision", final.get("human_action", "N/A"))
        if decision_label == "reject_reschedule":
            st.error("Request rejected by reviewer.")
        elif final_status in ("READY", "ESCALATE"):
            st.success("Request reviewed and finalized.")
        else:
            st.info("Request updated.")
        st.caption(f"Decision: {decision_label} | Status: {final_status}")

    st.markdown("---")
    st.markdown("### Execution Trace")
    trace_source = final if final else result
    if not trace_source:
        st.markdown("*No trace yet.*")
    else:
        route = trace_source.get("route_taken", [])
        st.markdown(f"**Route:** `{'  ->  '.join(route)}`")
        st.markdown(f"**Human Action:** `{trace_source.get('human_decision', trace_source.get('human_action', 'N/A'))}`")
        st.markdown(f"**Timestamp:** `{trace_source.get('timestamp', 'N/A')}`")

        if st.session_state.debug_mode:
            masked = mask_state_for_trace(trace_source)
            st.markdown(f"<div class='trace-box'>{json.dumps(masked, indent=2, default=str)}</div>", unsafe_allow_html=True)
        else:
            for step in trace_source.get("execution_trace", []):
                st.markdown(
                    f"<div class='trace-box'>[ {step['time']} ] {step['node']} | {step['detail']}</div>",
                    unsafe_allow_html=True,
                )


def _run_draft_workflow() -> None:
    with st.spinner("Processing your request..."):
        try:
            result = run_workflow(
                patient_id=st.session_state.patient_id,
                intent=st.session_state.intent,
                appointment_id=st.session_state.appointment_id,
                requested_date=st.session_state.requested_date,
                raw_input=st.session_state.raw_input,
                confirmed=st.session_state.confirmed,
                human_decision="pending",
            )
            st.session_state.draft_result = result
            st.session_state.human_edited = result.get("draft_response", "")

            status = result.get("terminal_status", "PENDING")
            if status in ("FAILED", "NEED_INFO"):
                st.session_state.step = "done"
                st.session_state.final_result = result
            else:
                st.session_state.step = "review"
        except Exception as e:
            st.error(f"Error running workflow: {e}")


def _finalize(decision: str, reschedule_approved: bool | None = None) -> None:
    with st.spinner("Finalizing response..."):
        try:
            if st.session_state.intent == "reschedule" and reschedule_approved is False:
                final = dict(st.session_state.draft_result or {})
                final["terminal_status"] = "NEED_INFO"
                final["human_decision"] = "reject_reschedule"
                final["human_action"] = "reject_reschedule"
                final["final_response"] = "Your requested reschedule time was not approved. Please choose another available slot."
                st.session_state.final_result = final
                st.session_state.human_decision = "reject_reschedule"
                st.session_state.step = "done"
                return

            final = run_workflow(
                patient_id=st.session_state.patient_id,
                intent=st.session_state.intent,
                appointment_id=st.session_state.appointment_id,
                requested_date=st.session_state.requested_date,
                raw_input=st.session_state.raw_input,
                confirmed=st.session_state.confirmed,
                human_decision=decision,
                human_edited_response=st.session_state.get("human_edited", ""),
            )
            st.session_state.final_result = final
            st.session_state.human_decision = decision
            st.session_state.step = "done"
        except Exception as e:
            st.error(f"Error finalizing: {e}")


def main() -> None:
    init_session()

    escalation = False
    for key in ("draft_result", "final_result"):
        r = st.session_state.get(key)
        if r and r.get("risk_detected"):
            escalation = True
            break

    apply_theme(escalation)

    kpi_patients = len(known_patient_names)
    kpi_appointments = len(appointments)
    kpi_doctors = len(doctor_roster)
    kpi_slots = len(get_week_slots(available_slots))

    st.markdown(
        "<div class='top-shell'>"
        "<div class='top-grid'>"
        "<div>"
        "<h1 class='top-title'>DentalAgent AI</h1>"
        "<p class='top-sub'>Agentic Appointment Intelligence for Clinical Operations</p>"
        "</div>"
        "<div class='top-kpis'>"
        f"<div class='top-kpi'><div class='top-kpi-label'>Patients</div><div class='top-kpi-value'>{kpi_patients}</div></div>"
        f"<div class='top-kpi'><div class='top-kpi-label'>Appointments</div><div class='top-kpi-value'>{kpi_appointments}</div></div>"
        f"<div class='top-kpi'><div class='top-kpi-label'>Doctors</div><div class='top-kpi-value'>{kpi_doctors}</div></div>"
        f"<div class='top-kpi'><div class='top-kpi-label'>Week Slots</div><div class='top-kpi-value'>{kpi_slots}</div></div>"
        "</div>"
        "</div>"
        "</div>",
        unsafe_allow_html=True,
    )
    st.markdown("---")

    tab_patient, tab_reviewer = st.tabs(["Patient Panel", "Reviewer Panel"])
    with tab_patient:
        render_left_panel()
    with tab_reviewer:
        render_right_panel()


if __name__ == "__main__":
    main()
